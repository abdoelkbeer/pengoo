<?php
/**
 * Plugin Name: Pengoo WooCommerce Connector
 * Plugin URI:  https://Pengoo.io
 * Description: Connect your WooCommerce store to Pengoo for automated WhatsApp messaging. (Enhanced: Platform Sync + Language Detection)
 * Version:     1.2.0
 * Author:      Pengoo Team
 * Author URI:  https://Pengoo.io
 * Text Domain: pengoo-woo
 * Requires at least: 5.0
 * Tested up to: 6.4
 * WC requires at least: 3.0
 * WC tested up to: 8.5
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define Constants
if (!defined('PENGOO_WOO_VERSION')) {
    define('PENGOO_WOO_VERSION', '1.1.5');
}
if (!defined('PENGOO_WOO_BASENAME')) {
    define('PENGOO_WOO_BASENAME', plugin_basename(__FILE__));
}

/**
 * Pengoo_API Class
 */
if (!class_exists('Pengoo_API')) {
    class Pengoo_API {
        public function __construct() {
            add_action('rest_api_init', [$this, 'register_rest_routes']);
        }

        public function register_rest_routes() {
            register_rest_route('pengoo/v1', '/connect', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_connection'],
                'permission_callback' => [$this, 'verify_pengoo_request'],
            ]);
            register_rest_route('pengoo/v1', '/exchange-keys', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_exchange_keys'],
                'permission_callback' => '__return_true',
            ]);
            register_rest_route('pengoo/v1', '/store-languages', [
                'methods' => 'GET',
                'callback' => [$this, 'api_get_store_languages'],
                'permission_callback' => '__return_true',
            ]);
        }

        public function verify_pengoo_request($request) {
            return current_user_can('manage_woocommerce');
        }

        public function handle_connection($request) {
            $params = $request->get_json_params();
            if (empty($params['api_key'])) {
                return new WP_Error('missing_key', 'API Key is required', ['status' => 400]);
            }
            update_option('pengoo_api_key', sanitize_text_field($params['api_key']));
            update_option('pengoo_connected', true);
            return new WP_REST_Response(['success' => true], 200);
        }

        /**
         * Exchange Keys endpoint for 1-Click connection
         */
        public function handle_exchange_keys($request) {
            $params = $request->get_json_params();
            $temp_token = isset($params['temp_token']) ? sanitize_text_field($params['temp_token']) : '';

            $stored_token = get_option('pengoo_temp_auth_token', '');

            if (empty($temp_token) || empty($stored_token) || $temp_token !== $stored_token) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Invalid or expired exchange token. Please reconnect from WordPress.'
                ], 403);
            }

            // Generate WooCommerce REST API keys
            global $wpdb;
            $consumer_key = 'ck_' . wp_generate_password(32, false);
            $consumer_secret = 'cs_' . wp_generate_password(32, false);

            $wpdb->insert($wpdb->prefix . 'woocommerce_api_keys', [
                'user_id'         => get_current_user_id() ?: 1,
                'description'     => 'Pengoo Platform - Auto Generated',
                'permissions'     => 'read_write',
                'consumer_key'    => wc_api_hash($consumer_key),
                'consumer_secret' => $consumer_secret,
                'truncated_key'   => substr($consumer_key, -7),
            ]);

            // Clear temp token
            delete_option('pengoo_temp_auth_token');

            // Mark as connected
            update_option('pengoo_connected', true);
            update_option('pengoo_consumer_key', $consumer_key);

            return new WP_REST_Response([
                'success'          => true,
                'consumer_key'     => $consumer_key,
                'consumer_secret'  => $consumer_secret,
                'site_language'    => get_locale(),
                'store_languages'  => $this->get_store_languages(),
            ], 200);
        }

        /**
         * API endpoint to get store languages
         */
        public function api_get_store_languages($request) {
            return new WP_REST_Response([
                'success'   => true,
                'languages' => $this->get_store_languages(),
            ], 200);
        }

        /**
         * Detect store languages (WPML, Polylang, TranslatePress)
         */
        private function get_store_languages() {
            $languages = [];

            // WPML
            if (function_exists('icl_get_languages')) {
                $wpml_langs = icl_get_languages('skip_missing=0');
                if ($wpml_langs) {
                    foreach ($wpml_langs as $lang) {
                        $languages[] = [
                            'code'        => $lang['code'],
                            'name'        => $lang['translated_name'],
                            'native_name' => $lang['native_name'],
                            'is_default'  => ($lang['code'] === apply_filters('wpml_default_language', '')),
                        ];
                    }
                    return $languages;
                }
            }

            // Polylang
            if (function_exists('pll_languages_list') && function_exists('pll_default_language')) {
                $pll_langs = pll_languages_list(['fields' => '']);
                if ($pll_langs) {
                    $default = pll_default_language();
                    foreach ($pll_langs as $lang) {
                        $languages[] = [
                            'code'        => $lang->slug,
                            'name'        => $lang->name,
                            'native_name' => $lang->name,
                            'is_default'  => ($lang->slug === $default),
                        ];
                    }
                    return $languages;
                }
            }

            // TranslatePress
            $tp_settings = get_option('trp_settings');
            if ($tp_settings && !empty($tp_settings['translation-languages'])) {
                $tp_default = isset($tp_settings['default-language']) ? $tp_settings['default-language'] : '';
                foreach ($tp_settings['translation-languages'] as $code) {
                    $languages[] = [
                        'code'        => $code,
                        'name'        => locale_get_display_name($code, 'en'),
                        'native_name' => locale_get_display_name($code, $code),
                        'is_default'  => ($code === $tp_default),
                    ];
                }
                return $languages;
            }

            // Fallback to site language
            $locale = get_locale();
            $languages[] = [
                'code'        => $locale,
                'name'        => locale_get_display_name($locale, 'en'),
                'native_name' => locale_get_display_name($locale, $locale),
                'is_default'  => true,
            ];

            return $languages;
        }
    }
}

/**
 * Pengoo_Hooks Class
 */
if (!class_exists('Pengoo_Hooks')) {
    class Pengoo_Hooks {
        public function __construct() {
            add_action('woocommerce_new_order', [$this, 'handle_new_order'], 10, 1);
            add_action('woocommerce_order_status_changed', [$this, 'handle_order_status_change'], 10, 4);
        }

        public function handle_new_order($order_id) {
            if (!get_option('pengoo_connected')) return;
            $order = wc_get_order($order_id);
            if (!$order) return;
            $this->send_to_pengoo('order_created', [
                'order_id' => $order_id,
                'customer_phone' => $order->get_billing_phone(),
                'order_total' => $order->get_total(),
            ]);
        }

        public function handle_order_status_change($order_id, $old_status, $new_status, $order) {
            if (!get_option('pengoo_connected')) return;
            if (!is_object($order)) return;
            $this->send_to_pengoo('order_status_updated', [
                'order_id' => $order_id,
                'new_status' => $new_status,
                'customer_phone' => $order->get_billing_phone(),
            ]);
        }

        private function send_to_pengoo($event, $data) {
            $api_key = get_option('pengoo_api_key');
            if (!$api_key) return;
            wp_remote_post('https://api.pengoo.io/v1/webhooks/woocommerce', [
                'body' => json_encode([
                    'event' => $event,
                    'data' => $data,
                    'store_url' => get_site_url(),
                ]),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-Pengoo-Key' => $api_key,
                ],
                'timeout' => 15,
            ]);
        }
    }
}

/**
 * Pengoo_Admin Class
 */
if (!class_exists('Pengoo_Admin')) {
    class Pengoo_Admin {
        public function __construct() {
            add_action('admin_menu', [$this, 'add_admin_menu']);
            add_action('admin_head', [$this, 'inject_platform_assets']);
            add_action('admin_footer', [$this, 'inject_admin_js']);
        }

        public function add_admin_menu() {
            add_menu_page(
                __('Pengoo', 'pengoo-woo'),
                __('Pengoo Settings', 'pengoo-woo'),
                'manage_woocommerce',
                'pengoo-connector',
                [$this, 'render_admin_page'],
                'dashicons-whatsapp',
                56
            );
        }

        public function inject_platform_assets() {
            $screen = get_current_screen();
            if ($screen->id !== 'toplevel_page_pengoo-connector') return;
            ?>
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;800&family=Noto+Sans+Arabic:wght@400;600;800&display=swap" rel="stylesheet">
            <style>
                :root { 
                    --p-primary: #2e69ff; 
                    --p-primary-dark: #1d4ed8; 
                    --p-bg: #f5f6f8; 
                    --p-surface: #ffffff; 
                    --p-text: #0f172a; 
                    --p-text-light: #64748b; 
                    --p-border: rgba(226, 232, 240, 0.8);
                    --p-glass: rgba(255, 255, 255, 0.7);
                }
                .pengoo-admin-wrap { 
                    font-family: 'Manrope', 'Noto Sans Arabic', sans-serif; 
                    color: var(--p-text); 
                    max-width: 1100px; 
                    margin: 30px auto; 
                    padding: 0 20px;
                    -webkit-font-smoothing: antialiased;
                }
                .pengoo-header { 
                    display: flex; 
                    justify-content: space-between; 
                    align-items: center; 
                    padding: 20px 32px; 
                    background: var(--p-glass); 
                    backdrop-filter: blur(16px); 
                    border-radius: 20px; 
                    border: 1px solid var(--p-border); 
                    margin-bottom: 30px; 
                    box-shadow: 0 4px 20px -5px rgba(0,0,0,0.05); 
                }
                .pengoo-logo { display: flex; align-items: center; gap: 15px; }
                .pengoo-logo-img { height: 44px; width: auto; max-width: 250px; object-fit: contain; }
                
                .pengoo-tabs { display: flex; background: #f1f5f9; padding: 6px; border-radius: 14px; gap: 4px; }
                .pengoo-tab { padding: 10px 24px; text-decoration: none; color: var(--p-text-light); font-weight: 600; border-radius: 10px; transition: all 0.2s ease; font-size: 14px; }
                .pengoo-tab:hover { color: var(--p-text); }
                .pengoo-tab.active { background: white; color: var(--p-primary); box-shadow: 0 4px 10px -2px rgba(0,0,0,0.05); }

                .pengoo-card { 
                    background: white; 
                    border-radius: 24px; 
                    padding: 40px; 
                    border: 1px solid var(--p-border); 
                    box-shadow: 0 10px 30px -10px rgba(0,0,0,0.03); 
                    margin-bottom: 30px; 
                    position: relative;
                    z-index: 10;
                }
                .pengoo-card h2 { font-size: 24px; font-weight: 800; margin-bottom: 12px; margin-top: 0; }
                .pengoo-card p { font-size: 16px; color: var(--p-text-light); line-height: 1.6; margin-bottom: 24px; }

                .hero-card { 
                    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); 
                    color: white; 
                    border: none;
                }
                .hero-card h1 { font-size: 36px; font-weight: 800; margin-bottom: 16px; color: white; margin-top: 0; }
                .hero-card p { color: rgba(255,255,255,0.7) !important; font-size: 18px; margin-bottom: 32px; }

                /* Fix for the "white box" text issue */
                .pengoo-admin-wrap .notice, 
                .pengoo-admin-wrap .updated,
                .pengoo-admin-wrap .error {
                   background: #1e293b !important;
                   color: #ffffff !important;
                   border-left: 4px solid var(--p-primary) !important;
                   border-radius: 12px;
                   padding: 15px 20px;
                   margin: 10px 0 20px 0 !important;
                   box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                }
                .pengoo-admin-wrap .notice a,
                .pengoo-admin-wrap .updated a {
                    color: var(--p-primary) !important;
                    font-weight: bold;
                    text-decoration: underline;
                }

                .pengoo-btn { 
                    display: inline-flex; 
                    align-items: center; 
                    justify-content: center; 
                    padding: 14px 32px; 
                    border-radius: 14px; 
                    text-decoration: none; 
                    font-weight: 800; 
                    cursor: pointer; 
                    border: none; 
                    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); 
                    font-size: 16px; 
                }
                .primary-btn { background: var(--p-primary); color: white; box-shadow: 0 8px 20px -6px rgba(46, 105, 255, 0.5); }
                .primary-btn:hover { background: var(--p-primary-dark); transform: translateY(-2px); box-shadow: 0 12px 25px -8px rgba(46, 105, 255, 0.6); color: white; }
                
                .pengoo-tab-content { display: none; }
                .pengoo-tab-content.active { display: block; animation: fadeUp 0.5s ease-out forwards; }
                
                @keyframes fadeUp { 
                    from { opacity: 0; transform: translateY(15px); } 
                    to { opacity: 1; transform: translateY(0); } 
                }
            </style>
            <?php
        }

        public function inject_admin_js() {
            $screen = get_current_screen();
            if ($screen->id !== 'toplevel_page_pengoo-connector') return;
            ?>
            <script>
                jQuery(document).ready(function($) {
                    $('.pengoo-tab').on('click', function(e) {
                        e.preventDefault();
                        const target = $(this).data('tab');
                        $('.pengoo-tab').removeClass('active');
                        $(this).addClass('active');
                        $('.pengoo-tab-content').hide();
                        $('#tab-' + target).fadeIn(300);
                        window.location.hash = target;
                    });
                    
                    $('#pengoo-connect-btn').on('click', function(e) {
                        e.preventDefault();
                        const appUrl = 'https://unimaged-thea-enactory.ngrok-free.dev';
                        const siteUrl = '<?php echo get_site_url(); ?>';
                        const tempToken = 'pengoo_' + Math.random().toString(36).substring(2) + Date.now().toString(36);

                        // Save temp token via AJAX
                        $.post(ajaxurl, {
                            action: 'pengoo_save_temp_token',
                            token: tempToken,
                            _wpnonce: '<?php echo wp_create_nonce("pengoo_save_token"); ?>'
                        }, function() {
                            const authUrl = appUrl + '/woocommerce-auth?store_url=' + encodeURIComponent(siteUrl)
                                + '&temp_token=' + encodeURIComponent(tempToken)
                                + '&return_url=' + encodeURIComponent(siteUrl + '/wp-admin/admin.php?page=pengoo-connector');
                            window.open(authUrl, '_blank');
                        });
                    });

                    const hash = window.location.hash.substring(1);
                    if (hash && $('.pengoo-tab[data-tab="' + hash + '"]').length) {
                        $('.pengoo-tab[data-tab="' + hash + '"]').trigger('click');
                    }
                });
            </script>
            <?php
        }

        public function render_admin_page() {
            // BASE64_LOGO_PLACEHOLDER
            $logo_data = 'iVBORw0KGgoAAAANSUhEUgAAASwAAABfCAYAAABSvPquAAAACXBIWXMAAAsTAAALEwEAmpwYAAAK3WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDIgNzkuNzhiNzYzOCwgMjAyNS8wMi8xMS0xOToxMDowOCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDI2LjUgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyNi0wMy0wMlQwOTowOTowNiswMjowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjYtMDMtMDJUMDk6MzU6NTUrMDI6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjYtMDMtMDJUMDk6MzU6NTUrMDI6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjI0ZDYwNzk2LTA4NmQtZTk0ZS04MzhmLWJiZjU1Y2JhMzkyNCIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOmY2ZTA5ZGMyLWNhNWUtOTk0Ny1iMjA3LTE2OTQ2NWJjZmRmNSIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmM3MTZjMDMxLWMzMjYtZDI0MC1hYjIyLWJjYWYwMzAwOTVmZCIgdGlmZjpPcmllbnRhdGlvbj0iMSIgdGlmZjpYUmVzb2x1dGlvbj0iNzIwMDAwLzEwMDAwIiB0aWZmOllSZXNvbHV0aW9uPSI3MjAwMDAvMTAwMDAiIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiIGV4aWY6Q29sb3JTcGFjZT0iNjU1MzUiIGV4aWY6UGl4ZWxYRGltZW5zaW9uPSIyMDY3IiBleGlmOlBpeGVsWURpbWVuc2lvbj0iNjUyIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpjNzE2YzAzMS1jMzI2LWQyNDAtYWIyMi1iY2FmMDMwMDk1ZmQiIHN0RXZ0OndoZW49IjIwMjYtMDMtMDJUMDk6MDk6MDYrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNi41IChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY29udmVydGVkIiBzdEV2dDpwYXJhbWV0ZXJzPSJmcm9tIGltYWdlL3BuZyB0byBhcHBsaWNhdGlvbi92bmQuYWRvYmUucGhvdG9zaG9wIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo5N2M3ZTE4Zi03MWI3LTFjNDItYjE5Yy1hMmE4ZjZkN2NiYWIiIHN0RXZ0OndoZW49IjIwMjYtMDMtMDJUMDk6MzI6MDIrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNi41IChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6OWNjZDNlNGQtMzc0NC1jNTQ0LWE3MmEtM2NhZTQ5MzVlZDEzIiBzdEV2dDp3aGVuPSIyMDI2LTAzLTAyVDA5OjM1OjU1KzAyOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjYuNSAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNvbnZlcnRlZCIgc3RFdnQ6cGFyYW1ldGVycz0iZnJvbSBhcHBsaWNhdGlvbi92bmQuYWRvYmUucGhvdG9zaG9wIHRvIGltYWdlL3BuZyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iZGVyaXZlZCIgc3RFdnQ6cGFyYW1ldGVycz0iY29udmVydGVkIGZyb20gYXBwbGljYXRpb24vdm5kLmFkb2JlLnBob3Rvc2hvcCB0byBpbWFnZS9wbmciLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjI0ZDYwNzk2LTA4NmQtZTk0ZS04MzhmLWJiZjU1Y2JhMzkyNCIgc3RFdnQ6d2hlbj0iMjAyNi0wMy0wMlQwOTozNTo1NSswMjowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDI2LjUgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5Y2NkM2U0ZC0zNzQ0LWM1NDQtYTcyYS0zY2FlNDkzNWVkMTMiIHN0UmVmOmRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo5OTRjZGI1OS1lYTUzLTA5NGEtYmZmMC1hN2NhOWQ0ZDEzZGMiIHN0UmVmOm9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpjNzE2YzAzMS1jMzI2LWQyNDAtYWIyMi1iY2FmMDMwMDk1ZmQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7WPvd0AACRrklEQVR4nOz9eZytWVbWiX/X3u90hjgx3nnIubKyJmpkrMKCRkScBQVRf4JKd5f+cGqh7XZocGwV0baxHdsCBURUFEVmZCyKoqqgxqzKOfPOcWOOM73T3qv/2Ps9ETfz3puZVYUKn9z5ibw34p445333u/faaz3rWc8SVeWV8cp4Zbwyfi0M89/6Al4Zr4xXxivjpY7k+Dd//V8+dfsXWcO0bCmd5bnLW0zHhyz1DWISev0e+5OSNM1I04LaOS6c7DOZzNkfl2ZW6z1Jml6cltnZ4SBfz3O7Oq9bY0RRBe9FvGIcYrwqRlFjjBdBPSooGAEwildUvcGKCqKCV1URxICi3qv1xgvqRbEAiAgowY1UBUGMoEbEIwbBq0FVRMV7xHkxSWJEtT08HNdbG0v2embra+W8fm5pIAd5mjKvU6qmwRpPIhakRsSTJga8pXQJaZZw7uSQlaWc1vnPyMPKUsveYclzl/Yoq5I0E8qq4dy5NerSsXdQYlOLomRWKIxn67ChGBQMrUFST56nfPzxG5xcG2JTwVphXjp6vYy2VXxTk+eGnb0pr3/VRVaXl6ib5s4LKPOIAe7iqFtrmM9bNrfmbO0d0jQ1fq4sbwyYl566dgyXB1gLvSLnyacPeO3DA5aHGT/7/m3WV3tkmSKiqG/JswTxStJP2d6dU0hCnihSpAiGybjCWouqZ2vngIunRmRFyvbenH6eUXnDvKzxTUMxzCmSDF9VeCDNU/AwnVW85bWnGPQLmtZ9Rp5fr0i5vnnARz5xg9FogJMWQTh3apWbO1v0ih5VndHLhIfuWcJ54dONgBIr3Nyb8OgT29QVeDyJgBhDYgQVQb1DvaFsWk6cGPAFb76XsnIv+GwxBt80uLIEkRf97CyxXNra5+nNfU6srbI2GPDokzdZGQr9PKE1lnndIj6ln3lWl1POnVqlaR3f+FX33f5+Pq3ZiEMVilQZ5DXXdpv1T14a/s7t6frbd6b2S5zJzidZgTGWZmrwqlijmLjKFUE13LyKR9WgDkBBDUr8NxRBEDyqgBhUPYiCCqo+zKGEV4UdJOG3JP6bmvgvAuKjIRQQMCIY7/F4vIaFkibC1VmDeofRyeHKrPn5nNlPrffKHx31Zh9N05S2TXD6kp7fK+OV8cr4NMenZbBUIUuUYVaxvadvf6Y9+3XP7Q9/z2G7tJSkBVkmJFZRHODIU49IZ7Ulejwe1MS/h+8lBe87owNeiWarveX3RCzqXfeP8dUSPkM9txiszohJZwKDkVGvKCb83HTvoYDFq+IwqCT4pD+6MtUvn5ftl/fs7G9v9PZ/4tzw8HvOjGbvzjKo2lcs1ivjlfGrPT4lg6WEMK3IKsYTHrxZXfwbTx+ufmXpR2SDhA1TI34WDUmMx1RxLriVorrwjkQtSBM8I03Ae5TgaXVui2j4XoyAOhQPKoA7uiJR0AShRTUYqc5DE/XhGsTFSzKoCirhtUQPzwc3DPUK+PAlgsGBa+klnv7IAiN22uUv2d8rv2S33f+Gi4Nrf2l9MPtBsT0q/4rhemW8Mn61xss2WIqQmRbra/ars3/26YMLf7O066ZY8vS0xmuFd+AlBmUmhHIhHDbB8YH4fXhRfAXBg4relnrABHyE4CupRA/tmJGJ8FV8TWdkbLBhHHlWIoSAUkGJIaIPv48oqopodOUWEaUiGjw2FYNgsEaxpiJLFLEZe3r2TdPxyn86r9e+72z/2p/qZ3q99v27QTqvjFfGK+NTHC8rS6gIvaQC9P5nJq9+75PT1//tJl81qZljtAognQ9At7EWYyyiBtFgBTq8SqNhEDUoLhgrJcR+qoBBJRg7NKJXRjDHTFMIHzUaPl3YmS5k9Aheo1VC0QDRh89WOogLNGBiql0SALTzyNQGQ2cUawVrTTBe3SXQkjIDm/Dc/P7f+8HNh5/amya/d5CVWNMZ6VfGK+OV8ZkaL8lgdUZiddAyLc1venT/dR+9Ia/6XG891s+D99M5RYRIzuKxGBYuEgZBQ3glRMPkOR5AqUhMCQomekRqBDEaTZWJISRgJNgskXAbMfzroPngWZljX51Z6wybosaFywj/O2YMTYxGOyDfIHis8fGXDSIW7xWvHvUN1leMOd37+auv+defuJL8xZVeRZqaV4zWK+OV8RkctxgsjR7I8S/vPNYYNkaejz85+ZpfuPzIjxyac33rJ7i2oVVoffBjMMETCsYAMC1GXAwLdWFERDsjEoxQeHHwhMRFy6cawHZV8HrkHeHDe2lIydJ5TCIR8wq3JAuwPXzXwVwh+FQ8irgu3oyfjSJ4DAQMzPhFKNnZNemMmSoigojFqdB4SHVGLTkfuPnIX37f4+k/GWYl/V7C8Ujz0/16ZfzaHxqzyqn1FGnLqKf00pY8DWvqlTPuzuMWDCtNXwhpGWsZZhUf+Nj4q37wIxe+u7e8zHIxx6tDW4eYEDZ1JAWIvpRIpCKE0C8A2hKhIR8ejNhgXlSD8fGgonQRIqqoBxFFxBw9SO3+CJ9hFum94HWFzGP3mug3LYybRIA/hIlIALJkkaXsjGln7MKfxkiAzbT714iJ4XEu0i4UBskcMyp4/9V7v77//kuz3/728Z9Ksz5N6z5tg6PBer4yfk0PoZd5Mpkzruwj43n2zr25O+Pb4tn1kf+5Ipk/UWQ99JUHfdtxq4VKslu+VRVWlw0ffXT3c//9L5/83v7aOqNiygIXinMqKqgLwHYwVILRsNX9ItMXMoNCfE0AjvCA6SyR+vj7NhgeHCoSPaoF+5MOgBKCodJjVAXFH722szCBgroweCZiWxo9r0CkOn7jwYvDgGBCeCoxNSAayXbgvEd9NI4elOB99U3JibWUn37qzJ8cDm5c+Y1vM9+6Nf/0F6Dicd5HL/aV8as9jDFYY3DmM+PzJEnCUq/lYOx/42M7F/7a1Ky/rcXg9xqsFdiCge789Bc8tP+nlwf6ob1JAnx6B538OiMI3mKwmnp+yz8Oe5ZLl/Z7P/zR0Y8NTpxlkE7x6mJ40oVgHq+ACkZ8CJmsIBI3uipOLFUbQk5rg5HxmAXYLV5RCcZLYqiFyoJ/pXjEpMGISBdassgUYnw0MmaRkVSC3+1VEHXEPCOKYjsuWAxFVQxGlADrg7XBGOGVIjVY4/A+GkoF5x3eKeoNi3BTiAFlMNyDrOH8uWU+eqP92/c+eeX7T24Mnt6fgPk0iqFaA3UrkXT7yvjVHKpK29a0zuLcp890Fwy0hzz+XPMHP7L3+n/B4CSZbUilxaQJiqFxOdenK+/8ycdu/Mr6ytYb7zk7+PD+VD4tUrJ2vyxHvMZfy+MWgzU+PFj8XRCknPPh50bf2Q7OLq3nU+pG8T6yyjtQWzvOksFrCAzFebxNaXyG8TP6ZsLGoHkik/ZyVVV76lUVEQ1RlPou9xY9IWJWsWOxiwl2jfATrGgXMWI6z0mjwYmwWKRQBfhIIRQlSAhBpfufxOepCF6sMd5Yg3NOe/28J9aemDbmTQfVMKsYkIhHfLXIKHZBqRcT8a+AcdnEYcXST0rmZpX3PVf+2P8w2Huo6A+1rv2nvgCNBIzvlfGrPIQ0MUynMw4OZrGy4tN4O4Uig8uXynvee+m+f9E/cYLUH+Jd+KzuoC3snMGqZdKc4Ic/NP/Z38rmPUUx3C8b/yl9vBJKc5wXzK9HgyWEkFAVlgfw7DX3zsf3z/yepSH4NqT2EcWpQX3Ei5BoTQwiglPDTpnRzEsurtx86sJw9zuGdvxDJ9eKX86ylEvXD3CuxYrgvYb6JBPKbNT7RbDno9eDgE0MvlVa5zBisHgkEbwLPpFTjwcSDE4D3hQ8PhbG1WswWIkJsHpM/gWXR1u8V7LEYJOE/cOSB09vMBwYbu5MTm+O8y/bmq/8nqd3V7+8MSNWex4rFZg2lBL5kD0UgcR6jA3v3zqll3qul6ceePzm9Fu+4NX1X9qTlE914VgrlNFTfWX86o4stezPWvYOS4rUfJpzLvSSkk9snvr2JltnmE5pW0HV4DuGDh5jFTEtyz3P/vTU6JNXp9/45vurP+/aT60gxXuQrNsHvz7WzC0zYZJgx5PEMJmN+eTuqe/SbAVXTxFjgvEwIN7gRFB1RKAHg1D5gr2pYSXZ3Pmsk9e+6ezK/N2DwuisNDRkqE9ptMBpiyPwokRNLD/2C/5TQK2C14KC9aEG0alDiAbLh3DPoNEYhTAzZBajweKFBsvrEZ1UfPTkNIkcMoP1lhaoXEbqhCTLbpxebr9jY3DtO9azzXdcmZz+a8/unXzH0rBHL5mD8RgTzkhjHTbpMooeFcXh6Q+W+Nj1tb+4kT/7D9dWl67Pqk+tGNoag5fslbrF/xpDPa2mDHpD1gdQfxqebZYI85mM9puVLzfGoc4jWIwhcAtjNlskeFq+bTHJgEvj0W89vXv1z3tj8C9zyYhAWXlOrGWk6a8fCOEWg7VzMMd7WBl4Lm1nf/DyZP1cb1CFEG1R0BcsNlZRI6EWz8O0zdg/rLmv98S/eMs9kz+xNCwOdqc9JpXiXEPRcUJ/jYyOxtA6KBtL1RacWJWfe+19B1/4K0/s/5kPXr34d9rhiJVBFaljboG9haxmYPt7BdqSzdkqH7669+1vKyZfsTdNX7bRaZ1jfXlAkVt+Pbj2vxZGnsDWDCwpvTSlapsj/PRlDCvCzX2+eH+emazvcK3BJJAkgQ8UiDSBQO28QX3w6Pbm+euv7/tTWdpsti/TYLVOKTLDsG+ZV79+1sstBqtXDEkSQ1se8vHLw7/msh7qpjHTEAD2wJsUzKK8RShdTjVr+Kz1T/zNh9YP/5zaVQ7KBO9rEvvf4K4ILrCPOJMRcM6FZKC1YC3OhZg+SY8YYXcbAkzmwtJSn9deGH/bSvHkox/effCHlWWsmYdFp2HhIQTFB2dw3uO1oUgTnri58rsfudjcc/H88Lnp/OWtQKdKYRO887+mDP+v5WGtUFaOnZtjzqyNsJJFVZCXZ7SMVyYTWW3rhLRv8dJx/ogEaAG14SeieLW0TtFWpKnNUFQ225dVo6rMK1gfZfQLy2R2Z3mgX2vjVh6WTRn1hUuHgy/aLDcuFInDtYIaH1P7JkaAIf7GK2JSvGt55z3P/bUHT8pfePS5IYVCUXxmdlUXe3sN5NFQRO2x8RpEFO9DuCeiOA9WwBiLDZeI90JRFGAsiYW6auj1HUrCwVzx6siTF3ebRaBuHJNxyhseTH/k3vLKb/6PH9cfbuwyVquYEpBFiU/bgteQLU2kYrtZ4uak/EMP3cNfrtr0Zc1DKkJhhMm0/FSm8ZXxKQzV4B2JVbJBw0qeUlbtEWH5JXpbRQ5ry+X7sgMHmiA2eGqigo8UFUFiplvwopS1sFG4zTe8av05k+S0LyMk7Qr+e1lJVX9mtNj+exm3GKxpVdE2FR9+rvgTDQVLNKiCaxUvYKzHil3wKwXDrLY8MHjqR95yz+FfaO0KGysT9iaezH3qrpUqlLUjTUO2BgJ+gyppYilSC8bQNorznsRkgCcVIcsSJvOGpWFGr0jZO6iYVpbVUZ88S/Fasndzj2HesLHSRyXn2Ztjdg4qXAqDu7iEUXCQi2cGrG30uTef/8jOdPt/+elnhn9n0E/wvsE5DSU7nsUCJIL9y8tDHr28/a619PpfUdvTl6rr57ynSBPOn1gOCYVXxn/VYcRSVQ06bBBV9ncmmJfBT5nMlCKpH10vps9ut6v39jPBY8G3AVKJqWyVgIXa1CPWc3pp/PN50rST+uUJ+aka+j0fvbVfX+vlFoM1yGEyo9hrVn5zURiM1OADkVM1aFEtCJUevMnZyLb233Bq+3cdzjPK+oCNIfTzlN1xF5K9tCEEL2peh1Kg8yf7IC2OHpNpxcpSEnGfkvWVJeaVZzppmdQtadoDrUgFej3LvHYYo7e47t57nHOh9g+ondB65ex6xqi3zPZhxdZBzcG8pWr8opwGgmflvdJ6j0jL/uGMg8MxibUsJ+Nv27Dp1+yU978lkTqQSdUE7482EDY0MNQHeUvdLJ8u2703rffll+f1S1tMLcpyPydJDL566XP6yvhMjcD9y5IEEcPyCM6f6DOv2pfsaC0Viib7f/ZnLq3/W5UBuBrnLd63UdPNgDWIVZz02ch3ecOZ6bfgC4x7OSGdIKZGFLw32F8/eDvwPIM16ht2x9mbSt/LB4Viu0weGoqLfajB6yZiVta89tTOt64uD8vdWY6YINU3Ghoa17J94PD27sQ3kWCoysohqpxaLzh/asD6csZz1/YZx01tTGDttq3StJ7WeZyP9Y7eBda8gHNdHeTdU7lC8JimpcN7z+nVghOjnN1pw+NXDnGEGkkI75nlCcM0AVGmdSSh1i0rg4J7Nw7+9DNPHvxs0e+RSRvIrV14iIaaRmNITE3ZpjTa+x1n1vWXx/OX4IWK4p2SJCmfAf7iK+PTGKrgnGfmPE6Uk+t9qsYt1Efu/ItBJvpND83/3fWDS9/34a2Hfm+vnyLU+DaJ9amCesPUZ2g15ovuufSnH75n9NH9mWUpfWknf0CWPa2vj3EFf32NWwzWweGM/Wn/HWmak9sWVQ20AU8UxWNhIOZNn6zZ8ieG1T8bt0McndAVtCUMehlplrK3P8XdJv7uYIDZ3GEyy4nVnHMneqwu5xigqj1VrQuj0xE1P9VhjVBkAeeqbE0/bUjsEDGBRzWvA053YpSx/Ko1KmcYly1OoXEtJ1dGrK4MqRuHjOTY+xrWliY/9+i1/Q9dni69cX3okVi6hASf1BoBMRggy3J2pvkXbe9s/x+1z+++qATa1jHoFxR5gtdfX3jE84dIoABYo/RzZdgj6ObbSJf772ADigT+4fWtKa71rC/3jozWXayWOnCmx72rl79qf1wfPrV38Y82dkiWJYiExFDdKoVu+YeKT/yFs6vZ3yvdBqovzaUOda2OxjeLn/x6HLdiWDNvx6V5e55JAKyjCL6IBokXLyAhXDqceh5emf7Q2pLZHDe3bqSuPC9PLUv9jL39Gn+MSKIK83kLIpxY73HmVJ/VpRQFqtqhPmRoXg45t1OmSSwkxtNLPb2sZWYqaklwjQx3yuSBaa33TKbL9+zVbunhXL5jkDfX6vrIdSmrcBoabVnJDK42NHmPplWub+6/4Ho8sDZwnFpy3/v0fvVG55XEaKeSgxEbFjkOgydJMmZl9sDNrcpEhZq7jqZpybMcY+W2hv/X+rBGKZKWXlKhwHSmF8var1/dckv7k4ayYjYvm8nQuKeyVBtMSy8TXCP/zfakMWF/XN6c4BU2Voqwbu9iUVWgqhWSIQ+fnX59xkf+2aE7+YfSwfLr8tz2qqrZNfXeh+9d2f+H1pXPlG6Z1ocS+xcbnQJJ49sFj/HX67jFYM1rOVO7/JxNFBvXg/NRYcoIaqKbqQZLxcll9xMtKXWjt0n1KlXjSPKC1fUEqyFsm5cO9Y6NtYLTJ/usreR4H0LC7vHcKYQ8bpSKFMg8XutQfuAqRA1NrRtVYx6+uiOvU9u/Z282vGdSFfeU2/Y108qutmSkeZ9ZbcE8+VlfuDL+KjX5LYaoDTUTCI7VpYzWJMwbxS4kbG4dlbeMivkvFPYQzCrW1tHIx5pGXfTwQbVl7rOzNs1P9wp7rXF3XlzeeQaDActLA5qmfVlAb5AvicY7UwZWkcyT5WBwUW/sv81QhMS0FEnJfC4nbh70fv9z0/XPnjb5a2e1eYNqyrNPdEmW02zvNfSm7Y1B1jxamPLxQVZ+dDkvf3S575/qZTUZtkNX/6vdkxUhSQzXtqYIsL5cUDf+jkZLCIbOOWVSZywv8b6zvfH7TqzWnNrIuLJZsXc4I0tyJoc+lprBi93UkbFq6Bq1/Pc4uq3TfVkDWCUxPsrsvDTf5BaDlWTp+dLZ084ZrHV0GsJGbajzo5MtTinSCb20/Ejl0qCsfocH5VqHNZayajFGOXuqz+pywvpqD4CqiqeCETpEp2P9plaxmcdVDb3E4RVKX9I0xcbuoX/d1q68duyWLjoZXmy9uaBk51SSU460V/sE5xNEEtQILhWy1JGHsmvK1jNrje5MDbPm9uqg3VrJCk+WHf/p8ybRwvkT7r1nd8sbYzWnjQ3zIbEIW0L5dqhYdI5ZLdTenBoavXY3QqDznuVeQpIY6ubFw0FjIE8dog0GKEtdKxu593DHPbIjLJlUddCrr3jkI/jqambUZ1lK0/zXQWZVw0IdJHPGs+RtT22f+tNbzdpv3696A1dmAeezHmuVNPKUrAUwTFVOT+b+NPDF7qChl8wZ7s9+2dR7P3tmOPt3J0fNz2dFn7p9kTD7M3UvQBIztle3piiwMgz0gzt+fCzsT61h6gzzNqOVAm9SGoTSOVKrJObYKrursSJiVu1/l8ZKVUgs9NKaTCpyk2L8HKsW3/pe49KlqpGTe3N5eJiVVx5eTd6X5xkid2krd/ybm3ucrlx2Uo3itNNXFxAX9aqikqcY+mlDP7OXW80j/+jOwyuQpvTzhtVRgqownlZ3XFgCpIlnWsm9WxP79sl86fWX9+y9Nu2dbkjvdbvpicPK9srK4k2GI8GimCS060qMYqwntQ6jVdQIDPGX+hbISHEs9dr3tVjqO4DZSvDoeiaLldS3v2BFGPSlXembj+4ftKclMUGGJtZaeo1V8yp4Z2i9IcmXT45Ghml9+/tXhaKv9AeW1rV3nFvVgPtkec3B3jzbmyy9c3c++MpJPXpr2fRf1ZIMShdqPY1RjHh66f3s7NdXMnPw6Ine4Q/2k8kPrAz8pTkZLzVz+XKHV6GfK4d+lj67f+L/2akf/KNt1Qfr6RUN+BKxMbPszaI208Q5tCG+xuFIMkvjV7gxWX1zW59+8/XJ/E8t7+x86Nz6+LtPL8+/a5BVN9T0qZpf3Q28MFpeubk3Q9Nw8Opt4vw0tYzHFYfzOfOK0Peg9VGlV3DO41rHtG3xHg5nLRttTZZzRyhABNomzJn5r1Cv1V1Fv8gwyVF/httfHAxyy+Wb7dKz26P/49LB6FW9rD88rB7s33B2xatda9WOWp/n01Yoy5I03/yG5cHOt4/LOx+gtxisqm2HZUtCFo2MAMfA9NCMIfxDmviD8ay8OW/vPKHdcHFTDaxjZ9vh/N1dd2OE3Mz4ladO/tTj44fuPbFSY4wl90qaGERaTA6DzEXmd71o96U+TKRrFZuAC2nI6LUJQY1ByROP1vPLh/tzyjuSODVmQx3zNpYk3WYIkNmaukn2kyRBaaHT5ApdL4jSXeGvxnJtZ94fTyoa/8LC1g7Lu+9Mn1P5gLK6vUUVhEFeU5az9cvbgz/81PbpP1myes5pBjbBpoKhpZ/Fhxn1xyosU5ecd83p8zdm0y/t2YO/d646ePd6sfP3Rmn5McxntomGVxj1le3N2bkPXLnnJ/b9va/u9w2pTBEUo4JaxWnMxBzTN1tIDGloBBKksFssjp4F7Rsat8R2s/LGm9embxxt7/2V00t7//j0aP7uflp+ODGOX81AMTxPCRls77HG3nbuPNB6T+Mc01lNXSrVrGIyHvP40yHJZNTjVRkMhJEGKg4vQUrov5ZflVrLdF7y6OOXAmfsLpxAAQpb8+j2qf94tX3wnakqWlqyNKVtgzR5B01kWYtLlvnwldn/VfhL/1TS4R0zDbfslvPnB8vPPCb41pMuStZi/z/tHM7gaWSJzNU3ZV2+eOzpFWY1VP2UfpGh7YuAiQKSDnjwzOzv7Pr5/53mfXrpJBoMXex8v4jgLWI1CvGFxW5seP+uQFs1cl2MQcUizFldzjdXVwaUt/FyugsRAzcPJzRNHcirdxiWGhFtQ49DWUzKgrenCqHZNNoKYkWyAmhfOHveK1lmWFvOb3sYqApZogyyGVf2Bn/0ozvn/9Zeubpqs5RUanIpUYmaqGLwPujii/GxWFwwLuiWqQWn6+bJwxN/5Ppk7Y88sHzlr1xY2ftLeeLQl0A6NEbCXN/htPXAytBw4/pk9T9/6MQv78v9J1cHM4xv8SIY03VYkqDXrz7w/KLybJjDkOyhK7Yn6pyJIrRkdkphQ8lL404Uz01P/MmtcvwnT/V2vse0l75tkM4+mGRLv6oVmAFfvXNQJsRmvSJYa4EGVc9k2jKvHVlq6OcWayS+jlib+qt40S9zeO9YGg24eVDz3HObLA173CkAFlF8XTJfuf9zVpZzfDXG+xr8nFSUDm4SY7AIS1mJ1dzUtb9vlFefvNM13GKw6gojCxnemKJTwuLvJIq1U1KAQWEFm7x4JblA03gqtaz1+yQvUsmpgIjlLY+U357wgc2PbD/8fVKcwOicpu2oDhp5Jyx4YoFJIIhtwkbw8fsojKWqqAtE2EQaell5Pc16uLusCiNClloc2QKzuN3IE0WMNd6BpuH6uusM3X261mPgVDixmvoHTgmT27i/XpWlXkZqLHVzq36WIgwKx/ZOeeGpvXP/6EZ94cuNTRkWFZ4q1KlHANpKxNBsfI6YwL4XFg04jFiMqSlS8KzyycOVv7g1feYLT2dP/MG1kVzu9Xph49wm5BAR2mZOU9a3DUlUIc8s090Dfuj9vZ89MBdPrg+m4JtYjxqmx4tG5YxjDkWniYZHYuwRnlJniI9gdgV8bPue2xKTGpwOeW42+ppcV7/G7h5+73pv558N0/lPFqmlaf4bFbgiZDZ0Wqp9i2ApErASZJNSgnR3bgx5MkDvaP5e+gi4oZDbBpWGUJAWOFsJQcZJaSNxtSUxvfgQ3AseuXOeNE14+2e/ijMnVkkSe0e/w4iQaMn7rzSfuD6Zv7ln4zOU4PGKCfxEYwxWfLgGm+Okd86re2kGSxZi6FHBM/S4it5VDEs6QfMFzPfS0k1JYpnOWqa9miIzL1ob5dVTJgX9bPZvLibv+y2b1Tv+80GzSirjgMUYAH+LnjuJxk7OQWuL7vqJ0sZRlVSBPGnK+bzc2vRKewcMq7utWk3ET+482jAjC+l4iQqCaJRyjqeKAs5DL7Xp8qBr2vG8zxXBtQmNO8q+htkyjIqWm9fqN3zw2kM/M00vrAzzOYnMcSZ8jlEfyaqdzE2ch5ithICxHFFGorQ1ivdzjEm42rzqN+yX+S+fevLK5586OXuichavtxeRCz7bHcrHRVjKG37lKfm2G825151ZaWhcE3o8agcvHOVrRNp4DMnCOKkhSHB37eFiE10Rh5ogNot0ZfkaMCRVhJIsEVRGPHm49tXP7K999cli58c2iv3/d6k/+75e6qheGmvgJY9Ad7h9E4nEGnppy/Yk+/17zYnPJ/GCV2qvUhHULAu1HjFyMGmbtF/+24dz97MkOcbcfuUZkRA2qr995KiQZ4ayLNmc9P/0tB4+aI3XRLwaa0kMKqJ4VambxOyPZ/PXr/h3F4n/eCUvfKYiUNcNKytDTp9XtvfH5HcqZRNhmAujfff+Z27qm4ue0HVjNwaMmFCbTLcOPLXmVGZwT96/Y8hzq8EK/W1Cay7tFBoWDzSkmbvNqCKKJKrcPma/zfXjVTmYOnr5Sys0VvVM64L15eaH7l166ov+00fO/dQ0O8XqsAJajOlO3vCndAkCAAmEvPB9MFxo0KFvnLDe45nlUXHQkpPcgQwlJhi++axF9e6rWzusapFb7Nz5EFtrNFZBmbWl6Em6upK8oJWttUJZKpPm1kUoCsNCuXStfO3PPnPxA3V2Kl3KJsH8dlZQ0qi4GnTDVFnI2i+axMKR+obENyYsfPWCEccwmTM392/88MfL975t99FHRqNia1qZF5y4dVVx7uIFTp4+SVU9D3ZQGPQMm9vtvY/unPnTRS8DKozppLGPPHhZXFpYwD56+BLNocceS3iY7hyg09gHj5WF5ms4nCD2xGwobI2zQ66Uoy+9NC6/dCnd/6ur6ea7l5PDfz0YlE/3M0PVwh2gwhcdnQc/m9ekqdwWjDaUPHfT/9HHDl73T9PeCkkeak7bJKxHxTOJnL26hd1r17/h1Nq1d57ZaH5mVt153fmoR3eH8wLRil9+tv8vH5u++g/00hSjPhbjd48/rOuKhH2xfPTG1W+456nr9/R7+Y3qdrkehSQR6tpRl9DI7Q8yAGmFVPiAePc/qYakT3hC8Vktur+HqG3WCs4WDy6P7uwBP2+7BEe7e9NuSogSrhzDkBRM03qzyOy8xHEwdQx7lqWeob4NfrO4Eo6MVuP7LA/lp1+99MHPudy86Scn8zPD1SUXvaYo1SFKJ98oxrLwS472adcwh8a1DAs+sjrqM67urOZoxOC9Y9a2iLu7HnuaKGK6vKCCWhCP4qJHEF2vyK9xmKz1cguEJQSyblXWoG1shxa8pGHfsLc3Hv34x06+p87OpEv5NGQ9JXobYhYnWPil44BtB7p3N3b0o6Ofm8VLRRx9c0hz4tXrN7z5qYvDS69bGvWpar3VaGkf13pubI6Jer9H/wS084aPPTv8tlkzYjWtcBI8IEGP6fWzCDeDHn7oCxAenUZtqJil0a4tW1CjDbikRJgi9mjygf8m0SNzQgTJagoDLk8Yt2cf2p+f/Ou5Hv715XL3584szb57ZOc/mmfu2SJV1GfU2pWD3fp8brs5BVJruHKjYm/Wkie3elkCpFJx+fDMH7bZiJRyodprRMmtj2F88NMHmeA5xc8/euP3jHjuZxp6t/tUvFdWVvoU/Qx3G5jFGFBXmcuTM7970O+R+MNwNSKBBI4E2FcgEc+J5ZzD6Sj7xKXrX3n/6frbp9XtF3zorWCoSwk8zTtYLN94jGueKZIWlR5C92y77grhsOquXMVyOOeeWTm//RvyfMVR9d5I7IYT0/jSleR0O19N2BwYjCSAvf1DvM0IxDnP4VQZFHGDxo1jus+jw7DCJveq+NZxWKYsD9NfetsDm/f9l8ezH92cDt/czzxiNS7eePdGQsG21wg0H/k3nSE2qhjfXCtrqO5SV2pEaVxMG5vYcOIOQ8QiYiJFtImxusEQrsF3YvMmJgA8VvV5YLUVcIr1YJOjR5MkhqSZ8gufXPrPE3NyeVTMwDusmCCi2KUgY3/FhWWOfxeJ1epd2HTcwyFglEGPP4DbAhijWKm4Wt772se2p+9+52v9103aAn9MYsIYpW4tLSnG3Mr86+WGnd3D089uDX9XVkgo3VJBfCdwGLFFghRKmB/bRXygQdFAtNPhD28uRvERdQxwazDMi3NeYLGKJGA1wQsLmEyiik0bwNDqkJ126R17e807hnbMaj756eW6+S+Zzn9lmDYfMcoliyehpLAJgywnt1BW8VnesgCUfmq4MvHMzAszyhYP3hxaHK2C0ITDNR6yiXRGLnZn8kLW680G2SqN5rdbcYjArG452G7ukLHT4IIZd5AY1w/hf0g+hfLbsCOCUEASjHrqUZvKvHHU7vYGqzvrBv00rvDbjzwBp+3V7KAN60pg4X5qxHhNlFvH47Shctm5NFm+wzs+z2D5SHvpFnOnoHmLdAGdo6WoNuF0e4kelkZ7Mi8d88qTZ8Kol1LXLZNZgxWLE8FIwnhakZaG86c3SEyQV1nunSYx9XaRtnPfCZpFax1wYRNP2xDcdp+JRJG04CwGmWdm16fljFl9N71sWXCBFkXgd3qliwWX8TWdp+q7JrEaN5K3QAtGK0yckDipJhF2b8yYHsxJss67Elb7LR+9mn7Ds5Pzbx8NPdLhc0ZRE97b+0hPPR7FR117omJEdxBE5gAh/Aot1MziQIoeEIDWpGmPj22f/9oHdi6/+8EL+c8ezI7eXwSSBMYzj2tv9UZs2nBtr/euUoaM7BEm0bV3k2AVscdCPdWguOk1DdCwxBNYPIYWKy2IDZCE17AXhbAZjoXfqF9s/u5LFsZb46nuSI0jzwJdwssqN936Ozf33TutzuilFfnEPUHb3mzb+nDnhrjHdmxb1jq/b/3wn91/0v2XeXOk9S7AyZWU8dxxba8me56+mhWQFu9ag5FOxSNcnYlQRQzOUSwH04o3v3rZ/6a3nGBv+kJjJCL08oSf+qWneeLZbYaDFxq14Ak58OrVR6egC8gsR96CQNAESXCqGGOaLDO0dzigAywqZJkNofgdtkVqhaWiudQz9eGc5ZHBoRJch25fql+kzUiN5WDmPuvmznYBD95W+O1WDMt7oyxWM503LXE2w2co6j0iqkZExXTNKF7aEBGsqWN0ZMhSwbmgCGqMBN6UDXpYzisb6wV5AoVtmc9d/9+/f+WD+7L66pWh4n0C0iy8CSFszK55xWLRdtcfF4mhZVAkm0U2jPK0d7pWQ+taymZ2J5hgMY406bv+heZYFb8QmrV6NKo5eEW8i6KEhDl2rWNWzpm3FUnk/Rc5PLc5O/3+Kw/8/aTIMW6KIngTgPzYpyhOwSIQxqvHBKX5kB0lHjz4I6oFnfEJr+y8at/hCuLJzIy5WeHnP7H3PUO7db6VwSJh0r3N4czRtHosZBYmZs7m+OKXFL0hxkwi0E5oNNJ5061iTDC+VhTVlNpZcDOMnzojlGJtr9XMlG2BSQssgqEKHJ64xSXiOF09gXaWAIn0iBCii2Gxts3iuYc+ltBgibLfUjDWIfsz85AV95AaQ1NCNfZMm5z9+bXfl3FpTUy6544pgaZWQQ2ZvY2HFR9N14fTqw2fHddHgBIj3rnIigZY+nZkiQVso11wdbvVqYCKikjwMsP1ee8QE/pbHn1uqGRZZNJd+PNOwwOTaYmIvyP9xQgYrWd56m5OvY468nQweEcOReiZZUitUJZmpRV7Dnjqdu95i8HSNmQuAmnB4H0bAdo4uQp0LYOMIMaCsXffyceGIIQ2yQ0iKSBRCYJF6lwil8UawVqhbhyjAuazafrjH1//xQO58OrlfoP3ipUAMngR0ACuB0H/qElFMBIsXFGPJwFtKKS6YVRiU9XbD0Po7OwX4cWdhzfBIJp4qokewezaPZmugasC3mRhwYV3FRF841ke5iwPs4UntNJv+IX95f+tlHVGdhbCG8+xQ6Lrfh1wBecA7xFraDSnmgcpIBFwXshSj7UNom1YULHxQbfkpQupYnjuFYZZy83J6XNPbE6/7qGz/t3PB4F7vR79Y3IKaSKUczuY1NmbE+MDvwofjUrncWqYWSdY4xGbUdbKueLpnzgz2vlbB4eTjx8c6vziqX6v6PUv7h7mn7s1y3/bQTX63Gk76JtkSJ46UgmF9cE+6aJHJovsaPR1zfOjhKNFewREKOotiJCIw9p2EWYnmaWXKkvGoG6Zwyo7PSx0rzlmsFykjWRoUMo+7nGKYmOuauH1yfFrMTECCdedJQmHh3P/6JP7TG8TBYgIiTXM5w1Fao+aER9/DaB63N2I3Z2O/dc1E1Y1qNFufYrzesfK/Oic0+9lJAm3TTKEa4RUINtu91wjeNPdbfTsfJj3MBsx22n7OC1Wb/+Oz6c1SAgIfHSrA5EvdPUwcjSp2p1qViLAeae3f/4NGHBVIEi9BORLFYY9pa3m2X95dP39m+X514/6NXiHiA0VHCKID+nvbo12eIzQGauj9/PGkhuHr8sb+4eW5s5VL8HrsYoksgih7vLiuAA1Gss2YmsdwBymWqIn6LwzTeNpYx2fsUJTOmZTDY1ogTQxXN1sl57ZHn79oG8R6tBdUUyM3qRjJS1CQZtC7fvUtSNxu5wsmiertt5UVTccZGvjefbwrF5Jk6xHnpZH2F9XbHvsFIw3hpWWpFdw6XD9m+85cfPdxhaBwB9DO5vYCPqHXypy2NzLvuRgnhdFz+O6zRHJs+hR5VtoWGrZ2VfeeuHSd7zhws2vu76rTJMURCnybG91aK8Ns+oX12d7fy+1uxu78+y3PLsz+sPTZuMLD91SUKY1ZXhGGjHCGIaHW5KjqCHulcVtx0OOeHiIaQnHjixe3CVV1Qe/LLWOpvXNrFKOY93GKG3rcfEQuGV5YPAR/e3WSchqdx3UFaNusYYlCA1Y32E9zxsa504QjLG3LYxfRBxOER/vyXTQxtEhFVOudM2LPaElxt16TnuExjeIuruqmia2IrHtFe/lbd676Ap10WhMDKkEe2M8jgTv/MYd3+/WO0w0aLX74OrJkfck8cEu3Hn1al1smfOSDJYADnzLC/zl2wyvMOwJvin7P/bo8s/fKM+9YaloaFSDZAvQWWfELKZffcQxJAJWBOsdFqjgG8FQ6sm1dHMwGFDdhcSaGsNh2XBzUpK8iFKCuq7biaFTaAhJu64LrIuL1qKiJFBmRkjjXKRWmFaOWelJ0xDsZLbl2l7++w7Kfq/XrwNjHRu7x0atsrgBifhE4zIGZtefH1z6trVe++4H7hk++tilPeaV8OoLfXa2qnNz3/9Dj9448aem7caJYeGjJx0AWfU2nvfQ/UUxFNaxPetfPCizzz97IvuFTlpeBKqmpXWRt6fQ2JbdWf7WVgvUhUypBBZrpJpI8AhiODEuU5aS7a3Pf236dTZ/Fc9tP0vVjAEbuxYJVZ1QuoKlpXz7dFZ9Z99e/U4ve5/z3M7g6zena1+x166upNmA3FZYMViJ9Id4HwveWdwcdMa+M0raGS5ddCIXumuO3nr0EMMTs21Y/kfrwsfMpNgXFiKHIEBDL02xYXl2Ie3CSnXG3FJXyvJSzzzywOiOGFaRJ9zcHXNjp6XIXkgFiL/VAXgsfKtovI/u3xNIbV2YKd2iuvN690qa9+kNUtydsv0Cw8KxNEqedvtVjIsjtw4WGJ4Q5JhUBGcsh9WdUfdbDVb0D0M4EiZQojFYAGUxfAu3E7KFL25+wkMvqwqnPjRkvctQhaUeVPPJ8OcfP/2+zfLMa5Z7LU5DD0DVgNEcZcNM2BTxlIg87xCDd6Q7DZ5j6w15Uj87m003J3N3V5a+QWnFBAG+F8ksxEPy6MTSDgQ30V0P+IpVwpdRNdYENQLt6tEsJlGMDaFx08y5vD/4/Y0pSF0T5W2iYY5PxUZGvzqYzjMyd+nK6y8++aVZpp+o9CReejjmeBFqn9Mb2KunerO/vpw+9o8/fK38oauTi5+9Mgi4JOYIFQpNvKPhjTHotO3x7M3szz50tvrdzoX6yyQxuFqZTlqSJKyLqq1pm6V707SrqxSI6rBiJADQomAMiTEY3/DIucl3tY2yPyk5f2KVnb0pjXshx6dplbK2VG7AxkryvtckO+87dbD1jdcPR//z7nzjj0xZe8AWQ3pJjVCF6zcaw/sYopuA/HX9ugOJNXLXnI0Z5eiRLeybD1hPiEH01FqvLXJLc4zNkSYJ4+mcq1uzIJ9y7OK1O9g1EpglJnKky9qGFReypx2uo8b529OGhCj9JIo1HiMvXMiB6tP1Vdd4CHXFNIFCrQv8j+h9hfPQyt39CjEB3ZnO49q5w7AA3l0SCVERHPk3wYmIfQ+ih+4U8iR/iSFhhM98F/KJCWnQeBoGLyu8woO0ofPencrIFkM95Bko7S3p9NsNH43VuKp6P/HR1ffvyvlXr48a2oVx6ppOhvpGvCK2a70kgRiqBQkOsU3wePzR+dI4x2Akj66urDJt7t65xhrLpJzjy9mLeljSMY47zrXYI8CXaNZjDB/Ca8mCu28ivgSTWR3Ih4khTYX9aXPq2kHvCzWzqDZhI0WDbIRIkQjQ7KxKGOr1g9/0hu231k2xeW3fkWUSZaQXtofGKVsHCYPeYOerv7D6nO/6hZtP3pifeGB90Cxschf+ezn6XRFHrz9gt1r5H25sPpuZrF+3LkAHSs6gP0DVxcJ12J/ah2d1wkqvjby4LkyLB58J+KFYy/rSjLXe9D/vH8C8mjHo55xaW2bv8AB3m4Oi866rRiibgiSTvYtrs79xL8/8jdLf/Mqt+eq7bs5Wv3iiA/JMSKTBR44TNh60EfwA0LhR1YcMM3TClR0xMx7PGjo2iRF/79m1dmmYB1G+OPpFxpWbezx3fRuTxlB0cdHhEAtH/NGRc+TNRG9AbQzTg4yDc8pxYP/423kf+g+2TmlvY9XC+6t4Ven2R8B3BUzAeaHbjRoz2OGZ4oC7gO6o0DQlSeLviGEBNM5hTXYYMpSxqiIKgYZ3j5hS3AdpknBzdza60/vdSmswIj4SMHXhWXUPmGOlFIp6xLtQtnpX4qgGNYdhz5Em0N5F8dUrLPWFtppkP/Xo2vu3/IVXry3VsY1XLB6NJ1dXZyW2ozQApIg09Mx+U7OUokFWOGTsAvcGY8GXV+rygKYt7nLhxO7WPhysLxL3qgnhxFFBg++qeheZINQHIxCuvDXxukViO3HvQhZNIRHlYG7eOG369FK/wOzVK8YC4jBqIkvYIn7Ol7z+8Kvf+Oozm1e2Gvar68xvQ1V2Thn2ExJjsGnCOx+68eX/8aP5Y/NmiTwpo3etC7b4EWUEiqRlbzYcXTnIv+L+s/yrsg2dtrNMWV3pxzIRZanf4+L+/N8//fGdt81klSz3GGuwJg9Qg28RFwQbvVqsOqr54Qe3ncU5w8F4Rj9PWO4Zqsphlu9+yLVOqeqUYb/HqZH/t6Piyr99YH33LZuzpa99Zm/5D0/L1b5JMnqpYnwdvKWuJtaEDdyV0Yuw8DwWBf/RcPsYeqN+fjiu584LdXN0XVUdDh2njtZHKk23PnB4VaPSgRdHBkwj7SScxIFmElj64jtazfNHfGnwyIyN+cTnvUYUvEE04FddOC4aiaNdo5YuVD7KAgQP+y5ntG+VlWHK8oqhbe6MSS/1lYOpP1TfgmQscGVi2BwNGSaUzc1LZXQqG97pc28ljgq6kPaNWRWVY4tFNTrSnaCfhizcXfdyyDaGcGlRiPjCCVAY9aGqp/YnPrTySzeq869dW3ZY2qPNiuB9DFtEMVF9QERQk9K08PDy5X/Yd1f+6oeun/phHb7+DXlW4lpikadBmpYikW2xPfRFegOGz6tDvPViw8sCF8FrDFHNkaHrgFh1XTjgwuloSJIgYbM/bmkapW496hzTKn8gSRNS2y7AWdFgCL2Eg8NgqJzlZG/7ueVi/iOPXTJYYzmxNOSm87eAwqqBHY0qVd3w0SfmrPWrx+8bXfmHj41f864iDdk8r115SSCdSvRsDQ3eFFS69M6lYvyvMDmowTlHngnDpTXqsiLvZbzt1Tt/Y7zz6GNTNr7U5r17ak0vzOvk4qRKlhqX431CrYZ5Y3loNL5yz5ml/ZacjpdqBD5reZm5K5nOGyCJ6/z2R0fwOJRZbalcj7OryQdPrY4/uJrtfstOtfO1m+PRV02qpbeWrk+vcBRZg3p7xJOTjqHUvdmxLdglJDRkr33b1j/3gacbxC4OTgieQ5J7in6KerkFbjAiOB8KYboSlbiN4jx3IWg87tRjE4pBP6O+DagtIvSKlDxPMBaS9PZeGF5UHUqMjgSiodKFYycCaqFLHHn1OA0s+NsNEchyy6XrM6aXApDuj/SobhmJccyadFbkAQ/3XQVGd09dFsT7sKYloWll6faf/Hxag2rQZOgmNIKQGrMZISPXJUNVy/nce21vu4BUlcQm5IUFaVDNbvOqMALADurK7Kc+Mvq5zfrCZ60vK9CEycBi8CGDo1HqRhQ14J0AGd4nnDYf/r7Txf4fs/kyX9i7/PYnxsNfulbd9+rclHTcqISKEyP/7OmNAQezu2NpeWK5cahMD1uS9O4hobWGwIMLInld9knliDqxaOQRONxNIpZEIBVL5ZVBPwl4GTDMW66OszNiAs4VA95gFH0HVYZsTtW2bKyV7x6XDYflDFBSa1heTkmsXzwfRclTQ5HCzEGeJDhSXnWq+vNX5+N3VW5AKlVgHpuYAT4G1qqGIvadafr5m9tjah/4dM45Dg5n3H//veRFQV23lLVlaeC+/+zS4ffn6QwVmEzmy+NS3lg12atIRufnMnhod2cve9358ltO33sv07lbrB0RYXmUc3Nzm5393diEI8yzbQPnbZFo0SA97NwRBlPWUJIhxmxfOFF/69nl69+6d3D1bZIuv+7q7OSf35oPHuglLcgxTLYLVxbejol4qS4itlaVRFXWlq2KTW7JkCXGMJ7XHBzUJMf6aylgtMVb9ZJ2VRndXo2+Xfc2MQTOM8vO3nT6wY/uMmtuQ2tAKPKUg/GcLDW3x5FEYzouhr4uRU2LMS5mlWPNsIaQrPP6EmM1t8LtWot2WcmDcoara5Z7BcvrPdrWHSVejo088exNxd243IUaMUEmkce9CPnDDzJr2D28M1Zzy0wUGepvSc9z5Ht2gLJxeG9pPfnSaJgkWVE/v/2UAmlimc/mHM7H5OmdPZlAXRA2x1P5pcdO/uLN9uKbVlYAF3hVnUrAwlsVF42WR5zBa868MZw1H/2Bc/3LX3VQrnH/ySUeeU0+vnj9xmf/xw8nTx5w4WRuZjgV+hmon1++seuZ13c3QkagUihy+6KJTZsIFlUjfpG06FCDo1KRsDBaB0kmeb9vKH0ErlUosmYRImZpjbXFukkMxgQd/HBwmEg7caHjD0GLKxf38cZndOrxtQPaljypwmd6ZWM5Y2qUNEsZxfNDjLCyNN9bv3Hwc08dLL1jeRBwpeDBxitXv6hrFFpuHNrXzTbS+1dHvafLGBLVVc3e3iHnzg3wGhoy1K1l3mRgEpIEbNIcLA/4mUTKnxkOUgZLlmu9LXrZkIOZo6lDnVSWBm/0qefGHOw3mHQIidKoYe4C98/mOc6mqIE8a0jThDw3tB6qFlqSABxbQ1VZ1pZzlnvj9+/uTw+bVqVtA0nZ2s56hGckRlEXE7HiYhbQLg6KwzLB2nb54XvyyqS9I9URDeqjmg6p6DRBujUbBB7f91ie7xw4BhGJWDgbEfXukht4Q9t6+kXanj2ZcTh//joVBv2Mx5/dZHP7gF6vYFa2+OfV9cW8sXfgVfxRNKQBaY2QasCPkEVkpWpc4+UW7KwzBdYY5nXJvCqx1jI+LJEEHn7wBG0TjdaxK+3nYHZd4y87rGQYsYSayS4yjBQXEzLgxhjaVu9Y/Xwr012TbSsh+4ANHkFXzrAwYDH2nLfp6nCpf2ZtZfBU+bx22AIYY9mj5nC+ODReMLzCoDDU8zm/9MTaL15t7n3T8rDFq0OinItEgO7onWVhEBpfsDsRVtz7f3Jt7dnfOWlWwDuapmV/AoPBcPya5U+89X03mo+WvfuXDWBlwiD3N5IkIbsLf6SDnTZ3S8rak9wls6kKedLQtMEDcF2tm3YYlQbDGw/vJBG2Dyr31FXPeG5IU8NkUvPkMzMgZAxTSnabpTzPgo+J2limEkMHIxhjoo5Uy6hftGujAfmxgoZQvmEYpftMJjO2dityq0xmDa2LAKiCK+DUYPKdz02qd2BSjESAOp6IeE/rHd6Hz5s1Q/ar4nNWUvP0gsdW9Ng6mDBaPuTs6ROMDya3PHevgbjaumBMpE7QKmHWFqQubPDEGtLEMJ017O9XbO150kRJM0NXC1jVirUJNjW0moJpMLYhzwxFkbA/aSlbaEhBPIOektLQzKqNxzZX/u7Hr5/5A0mvzzCfx+xZnF45xk6PaXcjQuUM1gRWvajDtgfcs3bzb184t+Yrl+K9x1pDliY0dcvWpAxSAQvsMvxprEeMGSXGBpURjQXrBMrLrQccqBqahtF8VlMeK9AXCcmgzc19tncPSDOLtZZHHjyNEXNLkiKxQlNXyS89m+Rt6+IaFkSOOpIvLJGE0K5pBZPY5ZWRZVrGG4jOSp6l7I8PGU8mSGIxCGlqufTcHr523HvvOk1zVL3R/W5dhcDbmMhG47hN6Ko0ABxeDUV2m/i2u6fj37R1dT2z/YOpmmWJC0QjcS1swJDVMuJpydnfnz+ylM6fKiPzubv3XmG5vDOnnDrS5Pa1el5h2BfaesxPfmz4C9v+wmcvjxy+benE2YwGFrt0mUg9eqStFlze8rzp9DM/9ZveYL+k9q/DY7HG0stgXjU4TXjV/RuXNzY23/rTz/Q/cbM5m6yYBm3GV2az/h11sML1eVJrOLlxAhekzu78YgmA9I1ZljezliyJZSoRvJa4GDt2TpHBzd1yOp9VNC6JpNGWupKFPpbD4FRicXso7rXiI0grMZSI2kJJwrhu7O5kHrzGzqEzwu4heNeSW+XqVkmRCyeWIEuDjAkCZausj6r/tDKuKH2ONTVGTMRhhNZZiFk+Iy1JWlC5/F7fzlEXCbEGMit8/MmbjEthOT9i2Jv4FRRC459yVPCepYbRMOfG1iGbmzXlXCmbhizLg9dybAOYGKaqD0TDQBPglpBQJBTeDrOG8eGs99Te4M88s7v252asDUdrFuNrQPDi44EYw7JunQONtyR4Hlq+/r09c/CTTuvnmlYOztxrpoPUfXzapKTW0u9lVI3n2s0xN7fH7B7UnDwxJEllIb5oRBCtcO3oZJHpIvPe0XM6Jd2Y0kIVjM3Yn9Ynr2/dYN52dYKhhMmjPHNljE0svSJlNqsZj2ec2SiYzcoFgG+B1rXL3nECCUXjgcwcPaoozxQKDwLe6nxBWen5tt6jadLoLQlZZtjfr9jcndIrCpoIEVgrFL2URx+7gfeejbUhs7IO2VQR8sSxP01SOLlIdgSPLjp7xi8wMJGgejGb31mM/9aQ0M5upDK42TqzHIxxjH01SHxYCRvRmoa2zWll8Hlro/kPmllKx7T2CmXThMyXsbTalfccNwYLUmj2Ix8d/sRzs3OfNxwo3vugFEqnQBDdy8h/CbVXitMe1/cc9y49+Utf9Q7zxadOPsjBNJTegGE6PqCcO2yiFIMV7hvVT06bpz/vZ55qfmqtd/jEhdO9HSc5/nbyw3HBZtbRqqVKDLfRMrtlGCOkRmmd3NfGzOCCQR5TLRKZmJ7QOefMRjE7uzFkXkGSWibjGVumWnDUcgvzQ8VXofOIdGIKcSFqpEw4dVQu5+DQv2bZHPy7aZODKkkaugXVFYtNWeSGWaXc8MrFkwXLBZRN8B6zpLq5lFVPVrU8GBomRo0sjfwkQkmWmBaTZXhN7u1Ji6YWkJjV9Fzfrbm+c5kTKzmSZqgKtQtdxF1MmPiOaoGSJpbxrOVDH79JKg2HY8ewPyBNzcuSLQpwkJCnSptUVGV5+upW+tXP7pz93w7c2sk8KxjYGmjABlgBTUDaxXF/HIKoG0PTjnnkVZPfbyTxm7sTpmJZGY0oZxWDIqVtPU9d3mVre0JVVSSJDZQQXzHIUpbzQFfJMxiP3YVWk3vSNGSQXJcdW5gp4roJEtaIoW6z1/dzS5pneK8kRphWSt1WDPoprQtGo209++MZJ1ZTcptEw6P0M+FwzGeVrTFJLiEx5DVQGox29WRAIDl7r3hyxk36JpsoWdQhS5OgfjKezqgbZTiQBf+sM1pJYsG1qGtZGwYIKHR9skxKe3pewsD6BcYe7EX04PWIpBsysS9RwC/vuWesmV2pGh5KzRF7HA11e2Li39WTFwmb0+Jrdg52/3xLSC0XecK8dMzqFmstIu0LNrpXGBZAM7E/+dj6L1yeXnjL2rDF+Vi4ENOznY3rsiiRKE3rM65sOV5z+tmf+Z1va9/pZJXN3XLRqFXE4HwsqkWo64aJE0b95ANfcPbRi4nJ5qpDtK24nRlPcFijTMqUgyYnyxsM/lY393kjSw17k9npvUn+hiI3ocAZXSyG4xgJqhjTYrW80ZSWtgHXCNY4Nk726BjS/dyw1bDXTluKREB99C6E4O3E9/fgJOHGeOldD5+e/JXBUp+yVcpW8S50TXbHANk8E6YzePTZGfefylkdpswrT5EIS3b+kZvOPeijDNDCJzSxkFoCEJ9gmJbpxd0DKB3kiWASw+Xdiiy1JGI4mFQURUrllNKHAmPvkljSkzI7aNgZ7+N9zs1rY6ryGl/wllP0CkFu92DuMEQEa6Gft1gatibm7TcO1/7A9uba146bUZ7mCf28wcqcLosV7kNj1soSKAc+arKbyBMy7Exynt3KvuqR+4p/ZceKr0rqVklTy2PP7PCxp3dom4YTo5xhP42k5pZZCWIsF08VVFXLaKBs7tjfNq16kvYczkGQBxbwHaYTDYeEDkFF4tmaFK/eH5s3rC27j9ROqFvHzcOGpX5yy9oNmKdhVkLbwNlTPbwahnnDY5vp72x0QCaRr6jHixwjKTi444G6kgs7s97b57U/2+u310QsVe2ZlkEuyXa9SY8N1XBoW2vYG3tUU06vD6hbKPKa3QP9rZVLKDxYaSM22okyhkO9ozvMqpYHTmTTOz3vW9C8k8vZ/NSyvsf5JoQm8cKsBWOPMjAqQmocz+0t3/vsVv+P33O6z+rKCtO5YzqruBPcoyoMCgU3z37i42vvvzS99y39frDW6gIz3XeFq7ECzViJQmqKNSlbB55Xbzz1C/+/L+adakccTt0tgHgXgtyyqFGq1pBmvb0kSco6tkY6/iXqsNpSS8aNasSjm322J7Czvc1kf854f87+zoyD533t78yY7o7Z3HJvrXVg89RFV3vh4EeQPGRlnKYUxleDzFxObEaWpKQmIU9yBsWQfj6gnw9Y6i2zVNjLaBtgpI4L5GO9lw9zpQiZVGw3G2eujZe+Ydh3kIYw83aPQTWEpIry5I2Gzb2GxGgINerptfEkgOVhcQYAHk3DnYhH1eJbQ1XLmpWWpdxTVjVP3ZjhgcR0G8gu0g0dVSZ4V6AYmtYzr1rqRjHGMBykdAXfdxsiISzs5bBUOFJmtE1937Pb+Td9+Prp9z26dd/PbTYP/U8+W82Xh45+UkVPNBw6qhYlCWTijmVN8OA71YFQHNOS9QdsHcrXFLrHibWC5aWC/bEwLQ3v+/AVrm6OWRpkFNnRua8aGtjOGs+1/ZZ0MKBBeGp7+C5nezjfHsEE4sNaERvCJNPVLQrWNDR2hae2h391qVCSvOD6YUPT6h33lzUwqxpmVcOJJUWbkht7gz8wLCL/CQksf5HoQYd7DRltEKsUScW0WTY39vp//P5TBVWpXL42huhhv9gIhnPOzZ19LCU7O2NuHPR+91I/jaoYCj6JEuZRj8JowA1FsNrSz+zNO73/rZ2fZ46hnX1/31Z/wTPEmiZO7JGnoCjeCziHlz7vferkt51du/GTp9bzT+7vTymK5AUhYHiQQi/zlGU5fM9zp96z4+97w9oI0IBPaVDJCwYxAr02eniBu5Kxe+h57cbTP/pVv8F8mdohB+MZw97RLaQRVKx9IF52Lcm60caOT8cvz4oLBk1zpr6gkgHzVhEmZBaauSdLPGdO9bHWRG7N0a5SFZZ7DTfL9AvV5hhaFlpdxwiBAQsMmZciq69kWb3feNtV8QRNKnf0zq5V+rZ9Ik08igmLNGIsoZVZ5NIYSKVl2M/5yI2zf7+untp/4EL7L22aMbmDZ60a2q5Vtefybk3VWi6s5Qx7ySfUOyDH2FBvF6LaGNpqFCFRpVUZIQlZLwve7awMevJye0Mp3VfEa4w5okrcaR8EKSIBo2SpUqQNqQH1SXptV75sUg3evj899Y5GB583o0+S5uRZS065wEhAonHqOj+FBEi4H4uxbczomcWzMAJJ0nKqgP1247de27v2O85vTH5g1xj2JgbTg2E/pTkm53PL/BIoDnXjEDflA48nf+1jV9dft7Hh8d6AJnSM+lANIQt2qJHuajz9Qnn68PRvu2f70tdcPDP/ng4DvNvI05TpvOTKtRs8s33yew7q1ZV+r6UJzTFRb/DiQrY91roSr8GoAXH0BzmPbp78Xx/Y3PvB6WT63qYJeO5LHdYmKA09W/GJ7aV/XqeraS9rg2hgtxfosoTdgRYI0FnaYKW5fKf3vsVgTZuGIq0+NEyn85lf7mVJoOp3Ve1eo2HREOvntmHfbGTf997Ze7/sdVfetLbEs5V/Id9KFQaF4+Bw1n/vk2fff2AfePXKsAntvqIe0gLURyPzu0ujK4mxjOfKfaMnfvorv8B/WVqc4MZes9BfSq1gRZhWnt1py7wRlrKcJWnJrOeYSOZimAhA1pox931mvqBE6FkllXbhpVljmNU18zbj9FKPsqxieBhekCaC9w275ej3F3mCMcG9F0J3HBsNrtcwj/NZQ5pPn+r3MmaNRTT0WpzPGvYPqoVy5KGFpqk/mDHH6xDRCjhSf0DiWounVEZNTY+P7T74L6a6+Y4LK+O/WSTtUw5LHV3x1IZEilFF8CRZ0NW6eTAjTwoGRfsfl/vNP7C2RySM0dXUhWyaRk+pRUw6TLIRT944oPaeQWZoWxcUYIkesQ2h/KJYOwLMAesMxGNVsFHZYpB7fO3IUodtW6pG8W1Niz0zq3jo5v7gS6b18HNr33/9ziw/XbYFWZ6SWqUwDegU9RYTWm9HPhyBVxjlPEKVRvBsVCy4mMq3BvFgxSNJvH6p8abPe587/R9ePb36J5Z71T9a7mkzKEK5j2hLIimpMaQm9OlrpSVPLEnekFi1P/XB9K9+9MaZP9dfKvC+wbWBptIV53d1pl0h+GIHeyGVEt8b8FNPnP7uN86unVnKq79jUqFIDYlpQymRMRhassQzKIJXZWjXf/Gp0d/c92d/X9GT0IhXJHxGZyqUoK9Pp6IRn7EYElombtn+u/e599w33P59J1ebf93LajIbRBQzG0ieNmJxiXEYbShSR547DA1t7c6995Mr/+e18twf6PcV17oY+EUZG+2SJG2sozWIWBLG5En1zEsyWKfW1xhkje5Xs+/4pSvNu/KeiSl5R8dyD01QfaD807I2bKnbsysf2cw/fP/Kla9fH5bfV6RJeK1tEW3ILOwf+Nd/9MbF7x/bCw+uLjWRwR7isSDhGwybU8UaDdI1eIzNmFXCxaWn3/MbXz/7orQ4yf7YLTJQiRHmjWf7oOZgHsBUk8C4TanalGHakpgWIXCZMGCwOApm9Ji4Aucs1rakOITnUUAkyLxs79bMD2vWVwM+0LQhFb0+cjz6LH/0+sHS2aIfTlBrNZAvO+BdNWbdDNqUrA/8D7QupyyDYWuayBZPj05QEWF16G6M9mbvv17L2wqR4DFGRrbpshwisVOQIbU1Ji94eu+er796uP/1G8X4x5fz9ietrx+vnB6My0RbL+JalaYNtGuxBtTw7I3apUV+31LPUrs2gvrBEwjeoSNIt8TOPOlgY7ud/65pw4H63FSN4pyIiMFgVASsFU3EqEaD5Vojzoc7CKFf+LP0hRHFPrdl+rO5XRbSk9PG3jsu7RsrPzrjJD/XuNS25CgZxkB/4BnSoNocebToovmoMUGMrsvQYoKRFBd4Va0KZe3JE0smwbj5+Oy7lH9AbRpq0+cDm/f//YE5+HOjdP7vR3n1oXHTv+nFNbMmc0mduMyJFytatca6eb5RT4vXbY0Hf+jK/uqF5ZUklD1FoYDg4PkFBytESrJIWsUFgEfJkgrTX+HjW/1vXc1uvmspm//blvbj0zq/2TppvRNTe8vuxKQY2dg5HLx1pxx+bcnqUpIKjWtZlNYR1kzQu7cL8ugCdBcXEhHe088cjVuTS/Pe95Z258/Nqf5NU7pHK2cPD+ZWK69GIldrWqW2oW8399O+nRUXJ2XvnYfl0pfP/FpS9BzGBwnn0AFJo0xEjJ00wgQajOBAynpY6MfvZLDkeMr4G//hhxkUht29ybkfe/zeK5qdJGEOeNS7YB1VYlo2nGLWKHlmaNUivmbZ7j67vlR+v6r7pKvcrFXXd6b/jq3x2h+c6zIm8XgXpVcWiosB0A2ZngBGigYva1JaHlp5+ud+42dNvrAhI0n7JElG1XrGk5ZZrZQOvFPyJJSleAmcE3UWp0JulbYZU473sWIoRmuU2qftWtcHyi1NzFrVpWN3r6RfgNZTbGKxSUrPwtKwYGV9mTSx9HuGvZ39/N+8p9irk5O93M4hXrsSOhlrTLsL0LYZrtzli1+3fWZl1LtRxsJZEcG3Db4uF+G0AqOe55NXzB//xSsPfvtSP8NIHfu5xaoDCQYxZJhiKjNWorY+pfGBCpGblsSExEiHfzVOA24iEkqcjMGYBGuDvEpIKEkgG9JlrgjGgNCztm7DaRuKhqNiBvF5mlBEbT14kehRhVC29VF0MKxbbJQTrlsXOycHYmMiBmwQYbQmiBRKlIYJDJcY4zsbPFgTcDZ88B5QCV6TMTE/EQp1G9ejbabcN3r227ema58/ldNv7qdlwJakq7kjlIOqxXlP65W6zWhbBV+TpSHsExyp9SRGMSZ0vXEOGp+gkpAkLb71QVhROmg9AXFYG/h1wXH1XVV0Z6+CIYmHk/eBaiEo4msSG+AS50MA2brAc0NyjDVkNvQ9DFBRpIAYH+sbY4ZSjn2vUa3Dx/2NYE3o2+DUULc1qTisQONbRMF5E2omI8zSNopqAtaQZ6HfYAemh8cRIRLVEKnZeB2xumBvnvLq9ev/+QsfmfzWv/y1b7itwbq1VX3VUpawMuDqQxvj7/qVmyf+wKgwMeaXyN/wMamgkV8TFAEMNWoMe/7svdu77Z9Bm7DgRHCSYDIh1wbfxpom003cUSwbnlKsOcKyNRYu9J/8yG945PALJRlRzRoGPZi3sDNWWieUbWDE58kx/aM4jITN7b3QmiXSpV5Is0uOaIulxcVF8WIjeAyG8WTO4bzl4XvWsNWMH/+A/ofr09XeiZUG5w0mPmwl4HFObaz/c8xK4f7l8c+dHFQ35pWQ6JHBatVTtp2Kdvj/GGG9d/g9Q7v3d0p/IV/KasK5Gzb4olegjzWL8cQMGIojkRg3ktN4DYRBCYTTPAmfIxF2VbWo97TKUSZIA7VAuo7VHX9GBIOlSGOFrNHFVXdyJUSFWk1kEYKCARvkdToIYPFaA4Xtsl+xaQHxQBGJQnGBcR7tNB3dQkxkyimx0Bc0crK8hjR/ikOMZeZ7FLrDqzae+iNvvs/98/c/mf3dD283b85tgrVR5tp3B43ETWZIRLFpBWlsviJhPlCLF09jQpGxUQ9RiFd81zHJYJNYRxdDQCMStdtYRBfHG754z6KTtEaXJJXQuEJNGrWsBDGhAL6wPiRFfJDzCcXbIXGlXe1ghx1JUM8Ign5x72kSya7xdwi0FqcO1JEIeJOH3WITTKd44eOzFSVNAe9RrcOz0YiP0XmOgqgJrEoTAUMChizGoK4i97s/Ot2/s6rmLUjacJCzNMjp9Vd4cGP7z5jyCodlD98K3oUwTyUApsZIPN0VF61/KExuQ7ttm4WJlSSYJe8DBiad4kIA821H/1aN7qLinWF3knA6f/YDX/jw9uckaR/vQ/ntc3ueS3uOWRU+OzEvnr0ImkMxnStgOqmRT2FkWUI5r3nsqef4rh+ffPtHr53+stHA4p3DqeK9wWsnd0vwWAyIzUh0zoMnmr81LAZkJqFI0vBlU3ppSr+X0uun9HoJvV6CTRLOnxnsPbCx93/PyxIkBbGhWSjBTqiLUigccVwMnYpDgrrYIcW56Hqbrh1cl0KJygBtWKzSeWFh8YaOKhY4pgighBARF0NFx1GLMQfeBRE8p/jWB+8q4p9Baz4kVMzCsPnwgUHTJHoR0XRH7XoVs/AskeCha1A3WmT34tOOek6d0kKLemVW9zmYGE6lz/3im09/7PWnlqt/bouTvOpC+sM9U4bKfw3v5TvMFiUcneFwFTUYYsGzeowGuoZ4EOdRF/BS54LB7LK6GruSGzERm9WYofSUtWFWHtPej5X+CyHO+F/n3QoSP9fjnYP4/L2GxhwIUfkg1AxaaTsmIAtFBlHKNqF1aTTwJhquI2WORVMSdHFQiQ+foS4QdSOoHZ0YH7BBga4oXBY8xE7UMhjfII8UPPWuHdu0yTjdm5Rvush393p3FGu41WBt703Z3p/yzPUxifVbbzq/+Q3jyYSy7cWSAMWakO42MRTp+ocq4OKkuUg6dN4FMpoGfWgfWxohQXCsKw1Ruh6DntYLO5OMJX3ysc+759o7esVSWbXw5JWKx6/BuLF4r2R3SNvfdYQV+XJ/6+jXEXoZ9JKSDz6e/18f23rwjy8v5yTShA3kFNeGhxlOyRBepQZUUk6PdrfWR+UP7pVC7ZXKdV+exis2SULZSRK+jLVUvsdrz8+/eS3ZnI/rLLLFIxAuIZUdxbEQtVEKNxgP0c6r8jFzHxee+FAn11WUSRsxFQ1hlhyFJBI3bdiyka6hxBM7elUL4l/AOoXOWETlWoIh6LzpkM53iAmJD4lS210IoR0+R3xdXCuh3szFUprOwMUOOp2UD3GTxMy2YpmUPeblIfcuPf63XnviyucVRfqxyvXY3JlCu/Nja4PJZrWo9A33G97FcCSyxOLA6zKM0TosMKJuiA9hTmf4jup0LBL3D8YwaRKWivEzG/3xJyfzlC4O7QyAdMkd7a7BL/4MZWaKSIlIFbh/piNPhz2m0hVVhwMl4JXCvBbWisOnl/Ppc43PsCg2et6KjfSPKEGDXySS8FH6Jl4p0qk+xEL5RYQT1k3AXONh5qP3qsS1EkLUNBFSm1LOK+7b2Pm/Tp8qdpP8zrXHtxisc+dOcu7cSc6fO8HKqXt455tH3/7W009953Tu8CZwORZ6VBoeVUhNR+wkfgntwjAJLaKejqCmeqT4YGLaOigdCErGYdlj4J944rWnnvnsLO+VdWN47HrNR56Zowq9LHqTdzUtn/mRWFjKK6r5/OKvXDrx01fqV/+JtdWMPKkXuJFqIK16p/hWF5iRNRZXTbh//fB/Hw6ykE2Toy+NG7uXQj/TxdcgVwyeUxu96Tsf3vrtvjqg8n26lk1dh+6OS7QwFHGxhB50wXMyQlCmxGHjs4nHDJ1BIgKyR4erxFP+aJjIpdG4UYMBulXjKfgmfnE2mGg4g0pAwJm6ULQjowavKR5BsXY17k1uWabSoWRhoyx0pDRskhAWhrVV6oCqVjbSx37i8+979A2vu9D8r5XrUTaGwhoOD2vq2nE63/rmti5RE704OhXdriwoXG+wV114S6RJeDolk4UXE+fSdEamm4eut7oNodx01vK2izt/7O0PXPktVV3iyegUOQg9fIgfFCMriQwEE01XZ6BieB3x0s6L0M77lBjWq0esxbmWN5y88psfWX7i96urSWz0ISVOuE/wegSxdMkeYglTcNE9mNiubPFojryyTteL4wZb49qk8xw9Vgxe+pxb2pu88T795rn20btQKG7BsMryYPF3nSu+b/n815RfO5198uSV6jW/2fZTEqnDARbvzXWQv5f4vLqJO/6hR3a3O7GNCTWJi/PLWsaV5Uz/ycfu6T/9NsjH40qYt56DmZJn0C+EIjM0CFkERxsTwO1EYumIhLA1SQRxHacFjAuutmoAeZ0PgGVo0R5wGIMnSwziPWkCoQtwjbWCb/X8UzeGX3f5cP0vHrCSbqy2+KYKmkFeERtySho3eedNGpS9ieHM8PDSmx4Z/DNJl8iGz++SHLCLXKL21vNCXJsY3vrI9Ce2x89+yy9efc3/waAg9YGpv9gfElPUuMWMq3bp4ojJiIZTuBOXkxgbBkApXkfwzMI678iUJu6bjgpKpKDExRhZy51Miu/MV0wMiDkqvdB4aBFfGzoMxYUcK/ZFO0N6tGa02wfxGhdu/QKo7kInS6UZrnSsFtefuf/0zb/YN/vfTdJn1hS0fo56z8Zqj/OneyCeUxvTf3bll3b+8ubkwomVXudBRpC+Y/jHz+/04RbSLGHyA0606LHXhcdCp9QbLtkGaofxlK7Pfes7e/edqH7Euzn3rm1+8nr5wKtXiqDRFUKoOL8RU5TOMujxA0eOJkE1hKzxuQYoJoZ0ItgE5s5yYXjl0dXe5PFsyOOnJ4c7N+Zn1nOZh4MkOh8a+SedeGCAGzw+6rzRebgSvPoF3OIBG7t1dw7iMQcVAsXHIIgTKs2YTXb5Da85+EPnTq6VO4dKP33preqP/iZC3QiVK3jd2a0vX50++q+u1g99tSQZ4uujw69zh29RdOhOeom61d1PtFt1qHocIYOTWmHeJlwcPvnBB5ef+6IrO8l42O9Tu0BuHPUVV9ZMJuVFdmQVJy4VURFP23pxKpJESYkwmY7EGsSLBj0qpXZxKynYJKV1iqqT1ql06osNKmlitKk840mdl3V62rcrr6p18Dnjdvi7Dqul1FhDr6jAK21qwoLwIaslnlhcGljo4pXaFRzu7/F552/8j60fsbu1+3x7FB6iV5b7Gf0iDZmoY6NpPT4d8sVvnn3zrHnszIdvPvg/Li/1SLU8OgEjh43obcVYG1RwnY6IdtpYXXZWjyxe9ww7nKpzubqw0HfNNGzckpHc1m0qjVlFiYTT7rq6zPKxk7XztEPTBSKRMNZsRhwkwAUddyqGs3K0CTpr3UXEimXuUuqqYpje3Hl4Y/fbTo/2/3avXzRb+wO0EfpZJ/QTJIVbHySjh0XRvuXe7S/98cf7vzKpTzBI5wSZnuBBdSzxyEMIlIn4r0rgeAU9Kg3ZOB8ImuHDAsjcaa4rgCnI9JAHRs/83t19ixHPa9cv/8H9y8vvb3Qd66eL2wxrM/YrXPgyGj3ZLvyPXlYknSImRGLi8BIOZBFD2aRItcXnftb4K06sn2F8eMCJ5Jk/+eR08F30BxitFgkWQZAoqtdlc8NT0kVCQjoipOkMdTykOu93weUjfN+Jb8b5bGTIdFzypo2n/vb9J/Pv3z1wtE1z3Ay9YNyt7TEioZW7lwFvvWf399mnP/jU5fZ1f74xS1idEsT7kmCkupOazvvTBbDb/VCiqe1kYoVglSuXcKq3+eHPv3fns/enIz9sEi6eWWZ795DUzLh+mP3mp/cvfEO5tfRlXFLJbJf41sXiPdZ0+QhqOMZ07wxpt+JD/zoXUu7R0Qga6VEyVyyYlCTLEJuQWE+S1iy4SPhQrhTVBLyPsX/ng4iimrG553ndma1/c99Z86NXbpZx079wNK2nyCxDyRYL8Pn/7myPt95/8D8V5pMHH7r50De2xYjczoGazgiF8LzL5kUvpuMidQYpYgudtnln6CQaqe40D5svLkU5/v5xnruL086b677Vo0N/8WKNsJI/ek2Xmegyf3ThB2jMCC4uRrtXeMSHMhYVi9eEyie4tmRoNrdfc3rv764MDv7h2jDZm9Q9JqVFteJ49YWIMJuXtM7jvedgLJw+mX7o7dWzv/Onn/T/YTo4SS+tEUIZjJjAdQseRRKujc4LjN5Gt2aiZxiwdR9fa2MSw1O6jGpW87lnnvmrD5/TnziYW4piidfc33ygNVf//z/99ODb86IgMTN8l6A6lp0Nwy+OklAKf6t3H38lGHQxeKvM2pSdnQm//TXbf+KRe0efvHkg1C7lTQ/pd+9Vl3/XR7Zf9RXrowRLHbEuUNeFhcGz6rzmo4Pu+EqOEczCDTx2aJqwJrssJWrYb3q4uuaB3kf/yWvOt9809yPG44MXTaDd1WCFhxtKWuauz0p+/S8Mko9++IndC//gxnTjRJIPKBKH8aGFOCa49yH+jdugi6G1O5E4HsfQekPbNKwubf3d/Unip23O6bM9Rn1hd3vC0zvLf+u58X3fWLJE0fckHe4Tf3+xEPXYZMZN12Uxjzw+s9i4Nk7eImiMbnaXKYJwEgT8J6SKfVwiGiWK0fgsJF6LFVrvolFKuHlgWZLnrn3R6/xXF4NTjMydO705hcR43PPVEI89h6r2tDLkkQuH39Q2H/ropdlDf/egPLGepxmJqTgqJg38Hu28Awk+kUSuVujenYSZiVSHRYMLJfx+VNuki746bKvjPnF0CIR5koX7L92C7kI1OTq4pItjO0wkei1hbXe/EzekEoyqdPNuUclwKpRVQtM0FMmUod3/2Knl7X98Yb36jpMr+eTmZMjhLCRyzB2iC7PATsP3kypldTj/gc8999SXf2yXfzstT/YHRYuRNmbJuvXRHUqdl6NRHTuE4+I72kn0fsQjUQBwUveoyhn3DT75jy6uV3+xN1xDMqXfXyIvUt740N4/ePr6x+596vDVf7Y/HFIk86NnoHGdxkkMZOHoGIhZzBtqFvfddbeufE5Tj/mS1139Pz/vzcv/980yQVPPmTMb9HPDl/V2v3L+nid+8lr1wBcP+xlWmmCeIuFXF2smQgIS14HaYK+7Z0sn3d1hgdE/1464aqjbnL2Zkvgt3nTi6jfet1Z+66Tq0/fcUYrq+LDf/M3fvPjmJ39l89Z/tEJVK/NZS17A/lRZGfhHTw0O/tEgc3Zn379hf9bPvQyx1kbeU1wMJqSXJRY1dvZYOusVjUonJdP3Wz80GR/+suQJGyPl8KB55Jcvn/jhG+V9vyfvZfSzOYl1iLRITNUaE+Jo0XbhuhvxoC5+3wZPKJbhhO+7rFMbs1IavSWPicbQREMl4qMLHK78SPTgCGQWiUC09SHTEjfh/iyn0Jv6lZ8/fcvq2mjncOKPNv9tvrwXkgTyTkKXsEiTxJCloYbRKczmNdPSUNj6I/efOPgn1o/teKpvnrSDtNEeSdL1bDwyRl2n7q77cTA+5simSNfqtDtIzOI+j+444jBdwV1n1Aj7SEyEqhfuLTGKOgqejs9dMHBRNijSuzvQPqDFBiINQCWh9kEGG22wWtI324/ev7Hz3a86tfUn15Krf2Fl6H8pyYe19wnzOhRzKyDG0DQOkZCN8m0LOLIsJUkSOuK0McJkDkuFPHlmae87E53eO6/TRyr6iE1iRs7HQyA+NOk8RBcPhQgFxLAolCdZWi2YVNDTm83n3HPlj59fmX6L04IiE5yHosixVhjPFardH7+wNn12dypfMnejDJsHs6MarX08pMVEQxUCtsAdO8LPRBK85lQtrCQ3dh8ePfGHPud1S38/6a0wmUVlW9/SNJ40T0mqq/+iJ4eD7VnxBXvVEJMkwf55jWTljlcFRmK4HMvCFnFMPJgMJpbbxBI7k+ClCGoS8wPu37j2nz7nwrXftZy5/9houPfRMI8k2DC++C0nb2uwXtykHV+6qszqlEG/N37TifZ/PTW89K1PbG2/a3c2+lJX97/AZz1MmkSdHiGznswGb8hppNp0mIS66BGFE9S3vnfufI9s4Hjskv6xT944/w8qs0K/aEBLOu5LMNsBRwluukZv9Og0QAOWhAaAL1jK7nXRdUUWhpSFN2hiNKa3YDza9UAkcnOM7/JjwV2OXoOXYOQb1yPXG3zZW7be8dqHTz25e6CsLN+dnupFMF5x/og0l0T1zappObVedN2AAWVaJQxG/f2Hz4y/aWi2/t7N+dr/2Mjal+3Ois+Z6xLWppiOYAghPIkGoWthRcSkcIKlxppy8ZqjcNtE7zWynxFahcb3gsHBB+xeulIkyyLLhyO05444Sxd+d2vKRyyEwIR3XgLHx3ca/opQk5ua1bx+eqlf/RJ68MsrWfNDGyvm42trfWZlwpVpgWsMNlOeX1n18oYyKQ3DYXb1kdPbX3FPNf685w6X/+f9evQV87Y3qH0aBBdN5CJ2SQWJrC21C66/b12o6NCGgbnePLK+/x33bhz8jVMr/WeeupJHfltcYpF/1bSeWnvcd0a+0/onfuTadO9/uzlb+bqDemnkpSARS5IGyaCk63EsBu8d3kDjDFXV8cBqVntb9YPre//0wsrNv+Rat3swT0n7L1Q3mZdK6XJedWr6TevLz37/J7fW//fLO4PfVvohWZaSpwlJYqK8kYsH1RFLvQsDu0ymKrjWIeoprJKZMUvp/NHVc7MfS93Wd5w5lX/Y+yE3rpYEQcO7h4HHx0s2WMdvsGmDtnWa97cePlf/5YO9p//ybOrfoOnS60w2etgkyenWu8Fhu/HGaTV4baf344/xeLqTQgV8q6yvyYdHo4QPPLf6fc/snv09Jsno23mckG4yOHJJ6PJHsogwj0JPFkZMIEZ8xw1G/N3OfSbCEMQwhbABgz084hUFr9vjxYJ4Fo04jcQabqFsU/q6uf+5D1/6nRsrS+/ZPRS8dwv/4najC01D3Vu6eG2Wptyclzx9dcy8dKwtZ+S5oSq75wB1m2ESvXbf+vibV5fqb75ys31LzdJb52328LROHlCbn6mdOTev3VmJSpOL9DWB4S5OkSRxtR9Y7x2JcTFEtIsC847EYixIAlmzi/o6zL8/Oni6DHbgenUE1ggKu8Wji6FC5wGaupfLDvjtBN1Ok/pmQrWZiLuUWPdsJrOnT47kV9QoB/MW0RxPj3GZUNd1pNjE977rTL/4EIG6FSrXY21k3it2672u2f6mw3nxRXP6b5q6/sPzJrl3WutDdWP7i/BYgtHJROln/lpv4J8szOwTw3z+/rVi/GOrK9nlRvoczGJG9TabVCQkX8aVRWy+eXFl/09dWN7/q3tl77eMm/7bar/0ulnLw/PGnPYuUoIMiPEkgE31munpU66ZPJXb2QdPj6Y/cHEjvzxreoznFcfL8J7/uc7DwTzl9In+L64M9377oHr2Tba38c65773Bmexeg7mvauWiUyPOR3kjPM7bRVOpUPvoXD+XJwa5u9LP5s/0pf7YKJ9/UOvJe06dGbFz2ONgbkkWTsHLGy/bYB0fTavM24SGPkVWfqRfzD+SJjVrq5bVYcrHr+Vf/97d3j/pFwYxR6TChZejMWxB2XEn/5fLT9r/5/r0xGv6vRZ0HoXU4jKMYG3nEXVGTznix2iHJ3UhFRrJhke/IyqLrsaG6MrHn0v8efg8oeP2QERVOkAhsvYxEXT3gjc5jYP1/MZz9yw9/T+MBr2nJlXK0otsoA6ZSKLV1WOvVw1qoEVu2TusublTsb5i40l35Kk4D7Mmo+8LlgblB4dF9cFpeUDtDOsrPbx3SS9P7mnbOpuXrWQWjzZ4deJaWC60vnw4+tz3XHrVd6Vpgtc2GGPpUtDxqkSp25TTa9PH33Lyqd/Rzue0GGlbJ2EOEI3lQgbUWouqwYpRFcT5FhNBfq+IF8vG2pK7crPeSxK3szLqt2WZsDRomc0b6lrAJpRlihpL2SpVK7EMJ5xMxgo2iSEIgU0usUln04Y117QOm3Q42UsdStkIsyZnKZfNE7b93qI/+d5iCLN5y2Q+W8+z/NTu4SxpaoxrPVmmnFzKy7atniwGRZsbhySGsu5zOBdMqmR3phgthgCth7LNWBkm2xcGzXcmycF3iq1omiZTSe+/tjMvjHekFj9cynQpSWZlNX92aXXgDiZzmlZp2pxJleE1UGCMEUxiWSygY+3rQpgO8xomVcagl/zKfefbX6naXdI0oSkn5DY7n+bZaGu/tG2DYI3WrTdt68QgurxceO+bXe+4euLkCkU6Z3rYYGzCze2CcZlS1g1JEflkqrTO0zQd+feFyabnj0/LYC1uVqH1QtkaWixzN+LUYETrdKWuHb3MsiiriA9EI4Qt3pMkwlPba79NTEIvraPWU8RDupo0uizDEXirscffUeL1iAB5xN/RRQZLjz6czjRI1zKr8w4IxipUvgUOi0Z1SjpoRSW4+wiilr0yJdE5FwfP/Ou3nJ/90drlk8OpZSV7ucbqzqPIDXXl2N6t6fejBHKch9Z5AnVFqFthVieUbU6rhlYzrHXtaNR7qq0t1tQUaeA71U1Nlo9YHSZ84Grx1zwJNqpBivEYUbyDNmJKRoLCwZDpz55cX/7kwX6K8xVNmwTxRdMdLIpRjRiRiQXNGmotjwwWaiyrox5bB0LV1HjJqH3CrDHMamgawBla58mPrWVVFgdRUzq2bs5YHfU5McgoK6AVGuc5s7EKRriph7QamNahHVVN0ctfUigihKSTay2+SaANOlhplu+sLvd2mralMkrTtvQKw2ipx+4Yap8HWZdW8d69rLBn8dkSOzt7i/WGNM1IrKmHg/yTh7MWdZAIDHsZ/TRjXjsqlzGrPVXbkhohTQ1VaEZE23jq6RytmoC9Hev10B2AaWqwjVA7YVollA6GNqXVjOVe78qgnzIpHS4BrCVpHM4F/HJlqWBaJYwnjtqlOHWUbYgZOuKtMYJvPSIGay39XsJwaLGJJeXF5+gzYrBEJMqttJw8dZrBYETZOJyo6WoOOYJ0OV4g2wVceaagdZCcjnHwLeEjXcgGncZ8CFdCNit4TTb21IslAxzF1UT2c4ixtbtwOvpFl6VdECMJZR2YyGamA8ejxyEpkypjPm9Zyba333jh5p9bSbf/X6/LlC2Lz7/TOG6sXsqprxrwsUWnJmM5nLSkVhj2QwNSRWLnnpDy73A+Lxpb1oe6z3nlaVolSZYZWsMvfsJ/3Sd3TnzVoCeERq9d+YXGRhGhwN2bjHk5h3b3g1uTnGmVkusMpwbfEg1WeFqGGHRqKB9Sgie4sP3xmZW10rpw7bFx9B3WWDDMdeNY6WfUjUcnNfODislhwyALrOnWBWE638LKYECeJqz0+jTOBWrIyoB5NadqW+o2FOi/nCCyq+5qXbj2uoXGQevC3FeNHtFkPsOjm8Oq0aCp7gQM1C2kEYftwk2rUM0c42ZOYpS2FMZ7c/K2JksNTkGHBSZL6FnDUpFzOG+pd+e42pMZwbsg3CcmwBpV7UnS8NldMjv8PRisqgnVHXHnYS0x653gNGGQWdoKtrZKTJ6QFyknN/qcP7tM27Z3fPbHx6dtsESgrGpSI1w4d4b11VXa1oXqdgnxgUSJEGJEFTCmrqxCOKLxQ1dzRoc5ybFQKYLAIWvSZUi6FLMJBdqqkbXuIrYiEU8JYVzH8whZj86lkkVYSXxHS9Cwlw5vQQN/TDJmpaWezcntjZsPrOx+z+e82nxzL8sOLl8tyNquNOXOp8XLNVbPn+/usG5qhySWs2dWeeq5bfZ3tjizMUTEsbU/C8C4SfAexhPPrILZNACixhgubHguX61/wy8+c/Gf5/0eljlqYsKCSAQ1RBVMx7y1DLPKv+p88gNL/T55NqQtlcnhPnD3LtqfzlCFedmQZCln1ge0jTJvPMYHCe0kNRh7BA8gHcbXxvtQUmvJEosxOevLS8yqipv7ezTek5iXEKf9dzqEoNnvXNjwqUlxrUPLOfNxi0tgfZRGOeSwF0OnF138vjGGxFi8Og72SpK2IcHSTCtOnOhTqwFTkCaGtmlj6Hb7OVNVGqe0rWOQWibzwCHMTLqIRL3rEi63fr2U8WkZLFWlrFr6RcY9584wWhpSlnV0+TsTE4BXOPJipMOGujRtNGRKdzLp4nsluI+GLqwTgn6HwXuLaMjLODWohBbJ6rXL9sb3iPGcuGh8kuihhdMwZBh9KEMQoUNhDC0YxbnAZLamZSCHnOhNf3B1ffojG8vjd1d1M0vz8xxOq6Ps293mjJdvrNIEsgTmHYwWh4nlE6pQ1x6hZGM0RGjY3j6kcQVic8qpoyw9h2UQsCsSWOnNubYtX/7+q/f+Z9sfkZt5xBc7NvxRXSKAtZZ6WvHQqdmPXTwzun44TyhyS2M2mIwnken9md34AtSNp6waTp1Z4oH7T7G7O+bxZ3YQky400Bd1fneYe1U96tfnPNCS2YRTK6ts7u/ROhe6vvwaGiJC6zxV1TBa7jEaDdne3WYwtLH4PnjaaSILA363+ekqUtI0KFI0DR0+QtN4rAwYLGWI9ZjDilnVkBbm2HuE8NV54dRahvFzJvtHKhTWhj6JJnaAOkafXBirXzUPSzVInnqvrK30Obkxwogwr8uYVhY0UTq1fPU+9qZiYbwWVxhnMvBbjjbggvjpY3hlQCShqi3GTelnkW9CmCRRwXVeEyE93tW2CR0PqIv9gvBa92GxqCJQFqJVFetJrKNI6t0iKS8Pe/6nl/Lmg818/z2jvn96ZX2Fg2rA5HDGauNf1FBBWGSJEazv3My7D2st/VyZl/UZdWma0lxKUk+aGlpnaBcPvUuzW+o2eJGKPaJmEHr/DQUSX+ObefL0zeVveXZ8///us5yRzGnbQHw0sQciGpqPhEXrcZpTJHMubkz/5u5hwXhWAopJMvLeMvV0j7u0eXxZI2StlOm8ZWlUcP/F05w9OaTIU66WwZNILAzzlmlZoq4BV5ObEnLLoSY0d+4UBUDtWlJrObm8ws2DfZz3L+WR/DcfQoAlJrOSIjXcf/4U957foKk9jbuJoPRzxbuSJnbU7NmEyoY1cieboIQ5zW2DtBWqkItjKU9QkzOeeZzCidURSZKyuTVm76CkrFq8KokxpBZOrBYs9ROubU4pvYYenVSIE8qS3DeuLkypaVbgJXlJRur4eJ7BeiFKrxrY1+qFuqowiWBMRt4r6C8N6PWyoMgYw4xuhOJm1IiCpKFAuJvxY1ZVOkBuAVcF9CM8mGC4nPeUTY/DmeHBtZtP3Hd65107e/tX+nmmoobGO+O80CrSNiqSdHUhXRGpZ9E+TD1ONdb9WbxVfKwn1Lg5rRhdWbJ+fcnMXOO21wbtzNsEa1NuOMuszUjKgJe8FEOlGrNZRqDx6EvcGbnxPLdpfsdPPX7hXw+HWb6STd+7lh38wsZK+UNWmg9YrQ+LxDIsHIlpSKWhn4f+kZltqMUxLDymqXFOmEybR7b2iz+8Nz/31VO/fj7NIdcSEEwSaR6Rwi+xGLqr9p+VhtODwydG/fqnb+7LUduzukGwWFKMtp+20QrhX4ug3HN+jfNnhuRZSllFfpoI/cIxq/zZD90Y/Jm5W/uCenDh3NXG1puPN89sjGY/dGo4/XtFZlXvMtEBTHdkScLJ5RV2ZxMat2Ct/Xc5Wuep2prlPOWh8yc4vb7EylIfVWU8npKnkNmS6zvu927un/wdavoXiha90cyvZLr3Exvr5bv72YDGLTJPIaoxhn7q2B9XK5uT4bvK+tTnq6SrV/Z99eRh9cT5tfJfnliS9ySmoKpb8jzl3ovrnJzXXL52wGxecWajx7CXYExooOJVGGYNh1P/pidurv/ZWodvc5uyJsLcNLOPbZSHP3Dfxvwf9fJeULN9ieMWgyUvcLiCdk+WZ9hUWFldZWl5RNEfkOdZSEsGxPQFNUBWY+7OKMb4SBqNAHzkrHS1ZbqIFSOOFGvebJTqPZj1KWcVF4ZPfscXPGzf5cnLmztBUUFUwQWX02godFbjF+8VTk6/0EAXDYWvYoK4nhrFGw1STtEbMVbpFTDoW6ZTQ0tC1RisNzgvvFzII0mE1sOTT+0znzbY9MXfQAQyKc0vPHPqH2t+JhdbsecGn3dYrn/e9ZvV/1LY5tC66ZODrP743GTvnTb96050cm1HagEOq346ddnwmc30zOZW7+2Hs95bx27w8NwNyNKULJlj1NO04WF1XWw6LTdiyBq0zBJ8M+P8ma0/671Q1fWxBIqCWDKbYn37KW93EYJkNcKpjWVWRjmjYZ+mdUE62RqyPGe57/jIJ5rf/cThq77roF7u9QpDkSulV2aVPHDpRvMla3bzj332ha0v7uf+ctVIVMy9/ai8J7WWE0tL7G5PaFrIiuxlY4u/KkPCwV43LdYbVlcG/197XxYk13We953tLr1Nz4qZwTIgABIgCIgiJWqJGEthbCuOLYlxUhVHipfIseU4TtnUg+1UKlWy86A4DxZTqkrKclmRElcpS8VlK3SiMCqZLsoOKVsyd5DYgcEAs/VMb7fvvWfNw7m3B0NigBkQdEjXfFV4mML07e4z5/znX77/+1GPK5ho1lGNQmhjMEi9PEwtJtAya3zr+bHfv9g/8DcIDxFHALMAMguK9JOd+fZjHw46j+4ZI+fbif9LMUZRFRJrfXzse9fm/mPOJpqU+XBIKqCXuEdeWcs/c7h26Usfn8o/U4mq6CUKxBJUqxGOHQ4x6HcA+IS70kAcEdTCHC+dY796ITn8+Y6pe902p+HAIAnfd3V18LcW1y/9xMdH8481a7TVG5RM2Jtjs4XizU0/agdEVWCm6isPc2M+sWqLJB/gw5Ab7dJSg9sV02VJ4V6RoQ9YMq59+GELjpanZhPP22Icec7RoEur77975ZfHqoP/YMkUegNfaTTW58eM85WmVDs4QyACr61trff0rDVIpQOhZS6syJsV0sK2YFwPu7OsD7mUJkV1bXv760ZwDhCCIe9nyLMUPKDDpPbNIDhBP7FjucGeRpxDUAXGbEHEjDCwlYbB6IOrKR68dEH/eBRMgziLM2ckLPwMRwuGrEOH+lk8pGhCwjqFoQQwDIgtK6e+pMcoHYouUgDrCcPh5sozDx0Nvp6aCI3XTcymlMCYCO1WDncbJXzrHKRyqIYE9YBgciSEVAarq+3N6+gyLLXU9724fOi/08oYxhsSRks46XOetdC3RXXl/iPPLbJnD+2XR8fHR3qD7OaesHNAFArce1jg7PwKpNLgf4mO1o3yS8Y4SGMQhwx7JuuoVysYb9YQcA6pDfp5WjgAAA+BtJ/h1dXZ71zNDx4dbQDWSBB4T5UzAiYEVs2+k988HXzv4yfWjkyPV1d7OYFwGq+cGzz87SsHvm6jJmJkcFZBG4IIFnGNYeDqeLF99GdHX7pc+6H3p5+CDaGNhVY+f6yUryiWX4JDYmm98nOvdOc+H1ZCjAQDGOuFNwkUKpzChByL3SMf/Nar156dGl8/YlkMqXbIw3Kvmw3uhotJYK2DzCU2m8GtD1550H1enRRSrKViIgoPqFAoJ2Wk6OCIVz9UJoLUEgeqF5541+zaT0W1amt+OUYor+NzEQIlDfq5RCUOsWesgjSTqNf8cNKl1RwHD9ShtEEvkchzhSRVaHUlYk5RidlbfpNyTpFJhYtX1hEwBy5uvm4lAm6hBK2HoYAeFnYoYMrGb1PodxE4RmEdAyEMjkfwK+mT5lXhaQqmlDB2xIfH1BciyoboUtmBFnMiCfFtOLmNENEWPnBP+vd4UIcbWLxBX40AYSgQxhX0u23wbTSxDl9KfDLWGIqqoJAqw+Urg430QbmOjKDTSoNnzkz/l8roJALahzFsWCggRWaZUYOxOMVaNjXzzLml//RIdf3RQb7RM7gVkhSoxAHGGgGurkgvKPoWw5+PYhxaMTDYWN9gHUUMNS5QqwrUKgGs01hYWvXpjNc9px5pfPcMf3xFHzw60VCANVBel3uobWatQZWlaOVTI89cUL//g9Xk4UA00VtPgj86Vf+GFk1UWQajS4I2AYr+4BEMUJ0I8N0r45+crix87dicfKKXbBjZnlZDhyMQDivr8uBzS3P/vlqLwFwK7YjXvuPEa7HBghKF2XGOhf704W88e+o3Tuxr/UpfimGpB7jrhmu2aWdpe6fSpt69N0WjrCtyUaXkBgHgSm2hoSSFb01xhGE9DcDNGh7Yd/Wz+8eyL1AaFy0NerhIUht0+xmatRhz+5twzkEIgeWWgRAUQdF8HYUMjAGCx8gGDicO1ZHkwIun17DWlYgrDAHbOb1guyAU0JIgDkdAtxrZewNEAki1qhPCEZTVwLIRz5W+IPHqrYXcccnOp36BUbBrYYpNS0gxhRple07xrR2KSbyeVuL7mi0ICZElA7z/wLXPjjf4wmo7x1bGljE/8YbuIF5m1HOKRht15LnGep8AuG6u5XVvFQiLC2vix1pyYrpa9fP9CLFgnACFJzhUtSUOcUhwrlX5xNzlhemxkWg4oehm6PUSREGAmakGVludN+VZ3wre8ybIc4KFKyk481zGsWoFTlE04wo4p9DSYnWxmNx+g+0jGHBlOa+fvjr7i2HEYK0GoQSCWJ+TLN0CQ5Bbh0honG41PtQ81frIg0fbTz13kf/CYlKvNkcUdMHlIwQQrFTg8FFRgAw8ruD0Su3X5ybWn3Au8rMCAAQhG3aYNCoap681HltNKxiryGEzOCtSPV5N1HmCsVWIoyquZdOP7e2e/VeEsf6NZohej81X4Z10gwngCCGuUNMvH00o2ZCdJsXPBR9KmRC9BBgPr5w7OXftk7Oj/Du9rAKiDch1nzTLDTiluO/IJA7ubSIMOF4934KUBgHXCIiClgxWS67lQIfMQjOBtrQIBcOxu5rYNxnj7HwPp+f7aHUyRIIjCukd3aSM+nBspTVAWavc9vIRwDrSBKWgVHlmFynlPdx1tsYUo5kKFYSys3WoR1Uk0WnZI1lyz7xx8oasNHbYEAO0Aqtdh/vGF37vkQdqX0hNBEK3Dq0oZdCRQDLowWo9HAh7I/gqHwFlDL3EgVIDUUyV2epVlCisp7UfyB1DbHwOzb+HA2GkEMzzHryxFAQKiQnQSoKPjdbVbyu9PUOaZLmvmBUKFG+V0aKFikk7j5EoCqosKBOIGlVo43XttXMAx6a9/3qEMcGVrvxEz4Soc1kwguzwXA2JxgAAApgcqQvR1o0fXllbeerMyp7vB41hVTlCrvCuCuXesqsAABpVilYSPfDafHqkVjVnc+WJxc2pETDhu1myzGClF33IgcK4cgBGsV+LPTicpuMcBDVoJVWR88ajx+bC3+0Nbr5um5aC0Tv312Fectg5a4pDYId61IQ4r1hNNpQQBjoCzADHxxe+dHy2+/NOhKadchDnwAtOlbEWvYHEgekmjh+sY2wkhjYG670cnFkQJ7G4Jn50OW38uEXl3Q40WjpjBxHL/u9MM/tag+V/SIlFq50j4AzvuXcch/fV8dqlLs7O99Hq5qiEFNX4zsQDhFH0ewmI6e6Y58OdgdZi3BXyw66Mz12pdrGhN4RCLQBDlldZBXLDsB4onK7r1HvLnKIrVAdgfSuTdQG6gxCT4Zm/+MgD+LtKNDGQCuQm38FSz4OjRf5ry9uPEHBi0e4rXFiW0Lq7rX3HyQCL2d0nmOAwVvlZiqQgrBSFHMCPKitnaFIR4aXznRMXzl6FJvG21h3w6YxIcNx/fBp8B17xTlAJCBbXHZ49kyAKbt9XCLhBqydmRSC8zBExniDk4A04LXt2UchaU8Qhw4Ur/eqh0QDNRnP0ctcBUZFmuU6LrKQBlXtMUIOMUIyM1g7eNROcHeTeM7+wmiFTDgH3BrGbNqcY9flhU+SoaZEbRnFBwhZ9LlSBUo5UBXdpLaHNzc/J5hzWHS7pekKanydHXKGrU6hFsmIxrRNIUoaKW1o/NnXpJw7NBE/0ZYw0teBlew0BpPZewMx4BXN7KlDGopdIUEbQqBKsLsvGUy/VvrEwmP4gFTVUY4ALh1w6DHJ36HRr8Kl9sfvWXfvyR+txvdfqauTKIgo4PnByEsfvauK1S12cutjFWlehUaVbehPbARcUKld45WIfaZqDi1KlcnsIqMJaWmt6g4VhJdXLmLghpawsZgDYEFgl8H2tBMVwUQc/yqtUvig5bL7QQMs+TWKhbIR2EqBhTj3zib+WfXD/7AxanRQBczc9VYR4AUPOGWTqtpR5cdaACg4SVjA5bouBoLdGxCO0r4ruempREYV6F3UgKMaWEQzllS0lcIYiyw0ONIK1ffVRpCbc7tL7MNo6GFW2i9zZc0EI8b23ymIszhEFZCdbYxNCYaFzm7c14KV9zNDgeLHBQkDQFUUwQmCkw97xSMEto9dfz7iooNSALwX6yj1GKXwqpthvIgAcI2nmKCScl0USDpxYME5BrAFjdkCMZ4c6B89qLzlgrrxES/00ipBrWCNb3b7FIL/5Qmx2NrfRLb1tFEl34woeFEo6lAYcYAiFMiGUlJiNzj1xbKr106B0uZdHUGYzEVNpC1Dg3fdMYbwRoT/Ihx5GNWTo9/vkj19tfu+a3Hu4OSLBaBcAgdMWIQHiKgEYx5o8/MiTLyz82aPh2vFKrWrTzCKTCpkEwoDifScaOLQvxItnu+gnBnrreY43xYYzxDAzvacIuXb2jHrs8MplOzJYMKjGHNb5oZzezXfDSqe7zssgxbu7wtHyN6p38/1L7UZbU1HoGLYfEYJc15EkGveMnv6DvbWVH3VkCkpTUKJuGc4WtZVbrow1DjpsYmKihmmit31OmxWL5cQ9Pd/Jv4/V6TB08e1VhQtRRBqUUBgwMJJhbpY9dWBqAkm+M6ND4POkybr2ypt3EIwRtPsacWCxf4zetrECgFBQMCu/uZDlMIjAHSnGtflwcMhF9O8MgMCoHPtn2cuzUzFeXu5fINAfKfXjvF/uhSvLwSagPn8sDUeNqNSm/ReuLZrhNOsgdAgCgDiDWDjU4/xcp2ePDr064oYS0YT6RnoLCkYNLBhi0cd0Uz4pgrB09LbEZg/rDgbshZAeKflZ5eXvjxXHehIgRgv3z1x9bCzuPE5ojH5GMCI2+3nO+WGpoyMRBHVYWu0W04i9lXZK4Zt/wb82P9hzeGIkA6zZUGCm3ofweWCFZmxxsTdz9OnXLvz2h+/r/nSSB8Pv3M+A1Q4QhwwPHqtjpa2w3pZQqkhQ72BpBKfIpcOFqx0Q0r0tTy1kEouD0WkiYrhi3t+mEK/8js7z3OB4cYN54bSN0iuF0wYgxm88lDksHx9S4iuMmWEQZgUPzV797JG99guXF2Mkednjtc2ixC1+yWqDSr2JWrMJpfKNL7ENKCtwfN/gy5c66b8wpAlBjJ8uY4s+UUsA50XmGHVIDcfeem/9wBR52rIQQbjzvV2phQAU+p1sR5/1VnDWIQwYGs0QWr85J4EQggM1+fLltPfihU7zZDO+XtvVe9KmOH3MOUgXY6K6pGpB679mpopj09njV5PBP9JogiEv08k+b1WcMQCwEFjvShydHfzuoQO1XifdMB2G8uGZq8c13DWWfuViK/nbOoxAITG8HQtRAlusgQOQZBZH6r0/mR1jZ1PFEN+iwLzpv0fqwVa/t2OM1R2i0ApKfP+Ql3DlSBVDmhnMVuZfOjp+5VN794QvrHYrsHJDYeF6GGvRqNYgRIzVrgK5rl+tGhOcXsC7Xl4e+/vNms9d+Om4RSjpmaveNbYOzmnUqxyvLI1/eoSd/zcjdflarl63EQtuWBD4mSSM+X42wrefkPeclBAToxxwejuuxxtQCyna0vWWVzkm6yEETUGJLtqUCjG9ovLnP3YZPtPrcjplIr0IGQsibpGeh0aIPKfgJsFsfO3J6frlX5yeqr2amyYy2cWddCx88pZhfCxGrSah1IY2/PZgsX+SnV/qrH7uj87WPjc6EsGYtFD1JBtUD0ogbQSmuzgxvfSpmIW2n8vb63K0QMyBlBPIW4Qq24WD/1s1RgQmJiLk+ZuPampxiHfLzj+83Ko9n+gpRGzgO4wpQKgBcz6toGmEtJfgw0fXf+bk3SPtpTWHA1PshXt7rX/37LWRn69HAoJIT2MiAMAA6xP4PVPBVHQlO7Gv98s0aiAc5kwJuOAo9VQYo3jwHvPfrrRbT51aOfiR0ZoFI6pMv8I4PsxXdPM6qFrEu+Z6n67WR2AH9pZbYpPBGnR6b3rxhg+WFsjtKufjoILDKI1BHkHKNu5pXvqtD9ytfm69J9AZBLA2L1jvm59hrUG1EoPQEL3B5viMADBa4+Jq9Aua1SCYhhsexVLfqhSeKypizsFZib4axeVW5e8ccu1/PVBbGWkyNAaMEdQCAZ9zvvXGldqhFgAHJwKoWyQRt0IUhGiE+Zfb/UuPLqfj71WcIgg4BKfgDGCwIM4AjBUhoBnOxRtWAIubrewPtITCWoFMMmgtUeVdTAbrT5+cyx6PXPf31nscPRkVsrW39bG3hHMWXHBoa9Htp2/g/N3y9QCMYbjvgPy1xfb5Y89dm/sxxmPEwnpDTr20cn/AwVwXDx+4/M+PzgX/q5cJsG3myW70rlHMEAwsslTd5jPe+EU4Z8hSicVlhTvBJGoRoB6bFx4+dPWnnjpNvtIjo6jFBEGQ+wNOODQY5KCH981c+s379tKv9hIBLhiCWhPH9i790/OLp+ba8u4f1kGMiPkJOUoBuQ2QSqDhLvYeOHDto4LW2vMLiR+tVlzu0zMCQrDi8nCoVBv46/esfnRl9fS3O9nhh4JAIOQKBBbWUigXQFoBLlfw3r2XfzIU9vT8UrYtL36Twep2O29+9QokfWAyVv/5UG3hZ8509r/HOoKJaP7q/QeWPjPeME9IV8cg76NaufHHNNahGnDsm6zBWOt5QteZX0KAmDtIK06WVSYfKdlh+b/wPYa0CgfAGQJjCSSpn6jULNyWBgvDZxoL5IbCOAfrssIw3OQ1xJfoc62hb0Us2QJp7tCoiWs/eKL/0Pxy50hqyCO9vPKwRnRyYIP7EyWIQQRnBZQioNSrNzLqIDiDc77Ezyjz0tQW0EaC2zVMCPXiaD35digXfme8ie8e2LMX89di5FohfssYaR5ex2lDiHEnyBKN0UYV7z3S/gdKvfani53Jn01lfMJQBsq8pNCYSf7k5Nza548dZH+Yuwp4cDvv5OHTDhRAfptP2BraGFBVDNx9k3CwSKjA/iny1ff3zr18qT35ubW8/lFtQs4CIGYDt4clfxzE53/z8FT4PyybRtrLwEIK64DcCNw9tvgjkphfWs0mfjKx1XfnNoDKJJiV/SP1/v+cFZd+KWThtcwICO6dh9JgOUsAU6aqCaSkcBDyXbOL72sr8xsX281PJ4PKBOEcnCqEVLkRuvy/j06v/urkePR8L2MwWhVrfXNsMliBuHPXqnNAHAWdI2PL763V5D8TQSgaWPmtidE4aacBBN/6FvdVDp85TlIFqd/Yo0YIoJmCtVUw5hN6rijnljxvB+c5SuULrCvIhoA2VCQpkG3zhrPSgBIKLip+ICdlgLn5rTtUnbgNEAJkCshNiEZNnZ0Q+VmdrX8JzqAnyf6BDh+yPL53eZ3vR8T39lM7JoSoa0tilTnBOWwckIRBr4vQtQRTl2KWvSZ078/2jPI/rzVinD1PkNkASX7dYIq3GMPc422sC2VAllv0ZYij+9UXZ6qXv9ga4AMTeybvFhxaDpLnRDo4NTpSQaoCcBivk3XbFgvXzdm7syCE3JSrtjP4g95NORqN4M8frC7/SE8tz15dd+8hnOLwBH+e58nltjJIpG+r2XhvP1BWuhgzzezx/bX5x7smvP9KF3eNj9E0tsl3RurB+lovQmY4toow3Ot+yiRgaAVHpwe/UiHLv27Y6N+0YTgT0bzPk87TqepcjqJxJDJANVAF4fjW6/G6pPuOV+qmyBWQaYFj+/UXa1WKc+dD9LNygvDWsM4h4Bz9PtDpJlsepJDlsDpeEpwWRLmykRqFuSfwf0yDsnXDJ50tKixdrbGBD6u2i4L8Rh2BSTU0ikbqt+igE/i1yBWgHYMxFIJZcOHmp+tkPgoHCI3FngmOy4sdHNw7hbX1BJevdjA6UsXkWBWDbgfVOoMEQ0UA/X4A6QL0cwFl6J2RnP1LBClCkSRnUC5CvaqeObKPP8M5w5UFhU7fIpUUkXPYxoX9VwoEDrkikCZEtUqu1rLuVUcoKpUKeqmBNL5w88bX+TVNlUCFMVQiPF/Ls+fHRipwaYS+5FBGI+LbNxCE+H7IRAYwEMnePfzrLDag2qAlGbI8hjR0xx79W7pfy4PczxgsYcPq3q1fCIRMIKxQDHWyboBKQLAnl08urehP+BS58exkU2qyE5TjpZzzBHtKOSpOYjwe/CnhAN1hEqHkuFBCUGUMWRh4DaodPeX24eV2gEwRWMIhLZBrDuMiWBLCEQWwEKABHA18Yt0y5JYCznrlg3ealdoCzgFK+3mCnHu54rc2oH3nQGn4/CmlXpFjm7DOyz1ry5ErAlIMt34zcI4gzT3dpFQ8uV28/bYuKUMpUwzD3HoLakcwM5L8zmurnX/bz/bwmGvfCEvhFQiI3XhewV3KTIwGvZLtH83+QMQ1MH57OSYHP0A1rgOp831Y/79Q3pvWFsMdnN94pSzuLnbxVwVvO4NlrEPIGaoRKRLtW8PBYbLJ8/unl//x/zk78hVSryCivlHUh4goWn8oCLVQLkSv08OHjnf/yd6DE/12nyJ4U+GcAyPAGA+w2s7Q3mHlaxe72MXO8LaL8kvaviun4dzkH5yfoTYzmn71xMSpx6XKMLA1OBf4BktQ35ZABDJXxyBReM/MxS/ee8B9JVUClHnFgNv/R+AIASUKcWBByDtLF3wXu3in4W3nYZUJQG3sLT0swHtQaS5wz3T/sf3y9HPPLez5tbW8OccYRyC80ieMRISFq/dNLP3L+w7SL6e6Cq3TO/aZnSXbz8/tYhe7uG287QxWieu6T27+e0U1QroYc+Pkq0xd+tp8/8oP9bPweDog1fqI7Y3F5hTXvScbDZGlegxUF4L8dyiCIzdive5iF7u44yB3sn9wF7vYxS7eSrztcli72MUudrEVdg3WLnaxi3cM/h/chzqwcZblaQAAAABJRU5ErkJggg==';
            $logo_src = 'data:image/png;base64,' . $logo_data;
            ?>
            <div class="wrap pengoo-admin-wrap">
                <header class="pengoo-header">
                    <div class="pengoo-logo">
                        <img src="<?php echo $logo_src; ?>" alt="Pengoo Logo" class="pengoo-logo-img">
                    </div>
                    <nav class="pengoo-tabs">
                        <a href="#dashboard" class="pengoo-tab active" data-tab="dashboard">Dashboard</a>
                        <a href="#settings" class="pengoo-tab" data-tab="settings">Settings</a>
                    </nav>
                </header>

                <main class="pengoo-content">
                    <div id="tab-dashboard" class="pengoo-tab-content active">
                        <div class="pengoo-card hero-card">
                            <h1>Boost Sales with WhatsApp Automation</h1>
                            <p>Connect your store now to start sending automated order confirmations, status updates, and tracking alerts directly to your customers' WhatsApp.</p>
                            <button id="pengoo-connect-btn" class="pengoo-btn primary-btn">Connect Store to Pengoo Dashboard</button>
                        </div>

                        <div class="pengoo-card">
                            <h2>Connection Status</h2>
                            <div class="connect-highlight" style="padding: 10px; border-left: 4px solid var(--p-primary); background: #f8fafc; border-radius: 8px;">
                                <?php if (get_option('pengoo_connected')): ?>
                                    <p style="color: #059669; font-weight: 800; margin: 0;">✓ Successfully connected</p>
                                <?php else: ?>
                                    <p style="margin: 0; color: var(--p-text-light);">Not connected. Linking your store enables automated WhatsApp notification triggers.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div id="tab-settings" class="pengoo-tab-content">
                        <div class="pengoo-card">
                            <h2>Plugin Information</h2>
                            <p>All automated notification rules are managed from your Pengoo cloud dashboard to keep your WordPress site fast and lean.</p>
                            <hr style="border: none; border-top: 1px solid var(--p-border); margin: 24px 0;">
                            <p style="font-size: 14px; color: var(--p-text-light);">Version: <?php echo PENGOO_WOO_VERSION; ?></p>
                            <p style="font-size: 14px; color: var(--p-text-light);">Developer Mode: Active (ngrok)</p>
                        </div>
                    </div>
                </main>
                
                <footer style="text-align: center; color: var(--p-text-light); margin-top: 40px; padding-bottom: 40px;">
                    <p>&copy; <?php echo date('Y'); ?> Pengoo.io — The Ultimate WhatsApp Engine</p>
                </footer>
            </div>
            <?php
        }
    }
}

/**
 * AJAX handler for saving temp auth token
 */
add_action('wp_ajax_pengoo_save_temp_token', function() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die('Unauthorized');
    }
    check_ajax_referer('pengoo_save_token');
    $token = sanitize_text_field($_POST['token'] ?? '');
    if ($token) {
        update_option('pengoo_temp_auth_token', $token);
        wp_send_json_success();
    }
    wp_send_json_error();
});

/**
 * Initiation
 */
function pengoo_woo_init() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error"><p>Pengoo WooCommerce Connector requires WooCommerce to be installed and active.</p></div>';
        });
        return;
    }
    new Pengoo_API();
    new Pengoo_Hooks();
    if (is_admin()) {
        new Pengoo_Admin();
    }
}
add_action('plugins_loaded', 'pengoo_woo_init');

// Action Links
add_filter('plugin_action_links_' . PENGOO_WOO_BASENAME, function($links) {
    if (!is_array($links)) return $links;
    $settings_link = '<a href="' . admin_url('admin.php?page=pengoo-connector') . '">Settings</a>';
    $connect_link = '<a href="' . admin_url('admin.php?page=pengoo-connector') . '" style="color: #2e69ff; font-weight: bold;">Connect now</a>';
    array_unshift($links, $connect_link);
    array_unshift($links, $settings_link);
    return $links;
});
