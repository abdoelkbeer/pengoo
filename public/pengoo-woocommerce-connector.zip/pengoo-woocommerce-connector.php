<?php
/**
 * Plugin Name: Pengoo Live WooCommerce Connector
 * Description: Live WhatsApp automation platform for e-commerce - Connect your store easily.
 * Version: 5.1.0
 * Author: Pengoo
 * 
 * WC requires at least: 3.0.0
 * WC tested up to: 8.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// ⚠️ Change this URL when going live to your actual platform URL
// Example: define('PENGOO_PLATFORM_URL', 'https://pengoo.app');
define('PENGOO_PLATFORM_URL', 'https://pengoo.net');

/**
 * Main Class for Pengoo Live WooCommerce Connector
 */
class Pengoo_Woo_Connector
{
    public function __construct()
    {
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'), 20);
        add_action('admin_head', array($this, 'force_inline_styles'));
        add_action('wp_ajax_pengoo_save_settings', array($this, 'save_developer_settings'));
        add_action('admin_post_pengoo_start_smart_connect', array($this, 'start_connection_flow'));
        add_action('admin_post_pengoo_disconnect', array($this, 'disconnect_store'));
        add_action('rest_api_init', array($this, 'register_api_endpoints'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'add_plugin_action_links'));
        register_activation_hook(__FILE__, array($this, 'on_activation'));
        add_action('admin_init', array($this, 'check_onboarding_redirect'));
        add_action('woocommerce_order_status_changed', array($this, 'notify_order_change'), 10, 4);
        add_action('add_meta_boxes', array($this, 'add_order_confirmation_meta_box'));
        add_action('add_meta_boxes_woocommerce_page_wc-orders', array($this, 'add_order_confirmation_meta_box'));
        add_action('woocommerce_process_shop_order_meta', array($this, 'save_order_confirmation_meta_box'), 10, 1);

        // Custom Column for WhatsApp Response
        add_filter('manage_edit-shop_order_columns', array($this, 'add_whatsapp_action_column'), 20);
        add_action('manage_shop_order_posts_custom_column', array($this, 'show_whatsapp_action_column_value'), 20, 2);
        
        // WooCommerce HPOS compatibility for custom columns
        add_filter('manage_woocommerce_page_wc-orders_columns', array($this, 'add_whatsapp_action_column'), 20);
        add_action('manage_woocommerce_page_wc-orders_custom_column', array($this, 'show_whatsapp_action_column_value_hpos'), 20, 2);

        // Phone Field Settings
        add_action('admin_post_pengoo_save_phone_settings', array($this, 'save_phone_settings'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
    }

    public function enqueue_assets($hook)
    {
        if (strpos($hook, 'pengoo-integration') !== false) {
            wp_enqueue_script('selectWoo');
            wp_enqueue_style('select2');
        }
    }

    public function force_inline_styles()
    {
        if (isset($_GET['page']) && $_GET['page'] === 'pengoo-integration') {
            $ajax_url = admin_url('admin-ajax.php');
            $nonce = wp_create_nonce('pengoo_settings_nonce');
?>
            <style id="pengoo-force-styles">
                /* Pengoo Admin CSS */
                #wpbody .pengoo-wrap { padding: 30px 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #1e293b; max-width: 720px; margin: 20px auto; -webkit-font-smoothing: antialiased; }
                .pengoo-card { background: #ffffff; border-radius: 16px; box-shadow: 0 1px 3px rgba(0,0,0,.06), 0 4px 16px rgba(0,0,0,.04); border: 1px solid #e5e7eb; overflow: hidden; }
                .pengoo-header { display: flex; align-items: center; gap: 16px; padding: 24px 32px; background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border-bottom: 1px solid #e5e7eb; }
                .pengoo-logo { height: 44px !important; width: auto !important; flex-shrink: 0; }
                .pengoo-header-text h1 { font-size: 22px !important; font-weight: 800 !important; color: #0f172a !important; margin: 0 !important; padding: 0 !important; line-height: 1.2 !important; }
                .pengoo-header-text p { font-size: 13px; color: #64748b; margin: 2px 0 0; }
                .pengoo-toast { display: flex; align-items: center; gap: 10px; padding: 12px 24px; font-size: 13px; font-weight: 600; }
                .pengoo-toast-success { background: #f0fdf4; color: #15803d; border-bottom: 1px solid #bbf7d0; }
                .pengoo-toast-info { background: #eff6ff; color: #1d4ed8; border-bottom: 1px solid #bfdbfe; }
                .pengoo-body { padding: 32px; }
                .pengoo-status { display: flex; align-items: center; gap: 14px; padding: 16px 20px; border-radius: 12px; margin-bottom: 28px; }
                .pengoo-status--connected { background: #f0fdf4; border: 1px solid #bbf7d0; }
                .pengoo-status--disconnected { background: #fefce8; border: 1px solid #fef08a; }
                .pengoo-status-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
                .pengoo-status--connected .pengoo-status-icon { background: #dcfce7; color: #16a34a; }
                .pengoo-status--disconnected .pengoo-status-icon { background: #fef9c3; color: #ca8a04; }
                .pengoo-status-info { flex: 1; min-width: 0; }
                .pengoo-status-info strong { display: block; font-size: 15px; font-weight: 700; color: #0f172a; margin-bottom: 2px; }
                .pengoo-status-info span { font-size: 13px; color: #64748b; word-break: break-all; }
                .pengoo-status-badge { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; background: #dcfce7; color: #15803d; flex-shrink: 0; text-transform: uppercase; letter-spacing: .5px; }
                .pengoo-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 28px; }
                .pengoo-stat { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: #f8fafc; border-radius: 10px; border: 1px solid #f1f5f9; }
                .pengoo-stat-icon { color: #2e69ff; flex-shrink: 0; display: flex; }
                .pengoo-stat-label { display: block; font-size: 11px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: .4px; }
                .pengoo-stat-value { display: block; font-size: 14px; font-weight: 700; color: #0f172a; margin-top: 1px; }
                .pengoo-text-success { color: #16a34a !important; }
                .pengoo-features { display: flex; flex-direction: column; gap: 12px; margin-bottom: 32px; }
                .pengoo-feature-item { display: flex; align-items: flex-start; gap: 14px; padding: 16px 18px; background: #f8fafc; border-radius: 10px; border: 1px solid #f1f5f9; transition: background .15s; }
                .pengoo-feature-item:hover { background: #f1f5f9; }
                .pengoo-feature-icon { width: 36px; height: 36px; border-radius: 8px; background: rgba(46,105,255,.08); color: #2e69ff; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
                .pengoo-feature-item strong { display: block; font-size: 14px; font-weight: 700; color: #0f172a; margin-bottom: 2px; }
                .pengoo-feature-item span { font-size: 13px; color: #64748b; line-height: 1.4; }
                .pengoo-actions { text-align: center; }
                .pengoo-btn { display: inline-flex; align-items: center; justify-content: center; gap: 10px; padding: 13px 28px; border-radius: 10px; font-size: 15px; font-weight: 700; text-decoration: none !important; transition: all .2s cubic-bezier(.4,0,.2,1); cursor: pointer; border: none; width: 100%; box-sizing: border-box; line-height: 1.4; }
                .pengoo-btn-primary { background: #2e69ff !important; color: #ffffff !important; box-shadow: 0 2px 8px rgba(46,105,255,.25) !important; }
                .pengoo-btn-primary:hover { background: #1d4ed8 !important; transform: translateY(-1px); box-shadow: 0 4px 16px rgba(46,105,255,.35) !important; }
                .pengoo-btn-lg { padding: 16px 32px; font-size: 16px; }
                .pengoo-btn-ghost { background: transparent !important; color: #64748b !important; font-size: 13px; padding: 10px; }
                .pengoo-btn-danger:hover { color: #dc2626 !important; }
                .pengoo-disconnect-form { margin-top: 8px; }
                .pengoo-help-text { font-size: 12px; color: #94a3b8; margin: 10px 0 0; }
                .pengoo-footer { display: flex; align-items: center; justify-content: space-between; padding: 16px 32px; background: #f8fafc; border-top: 1px solid #e5e7eb; color: #94a3b8; font-size: 12px; font-weight: 500; }
                #pengoo-dev-area { margin-top: 16px; width: 100%; }
                /* Select2 / SelectWoo Overrides for Pengoo */
                .select2-container--default .select2-selection--multiple, .select2-container--default .select2-selection--single {
                    border: 1px solid #cbd5e1 !important;
                    border-radius: 10px !important;
                    min-height: 44px !important;
                    padding: 4px 8px !important;
                    background: #fff !important;
                    box-shadow: 0 1px 2px rgba(0,0,0,0.05) !important;
                }
                .select2-container--default.select2-container--focus .select2-selection--multiple, .select2-container--default.select2-container--focus .select2-selection--single {
                    border-color: #2e69ff !important;
                    box-shadow: 0 0 0 3px rgba(46,105,255,0.15) !important;
                }
                .select2-container--default .select2-selection--multiple .select2-selection__choice {
                    background-color: #f1f5f9 !important;
                    border: 1px solid #e2e8f0 !important;
                    border-radius: 6px !important;
                    padding: 4px 8px !important;
                    color: #1e293b !important;
                    margin-top: 6px !important;
                }
                .select2-container--default .select2-selection--single .select2-selection__rendered {
                    line-height: 34px !important;
                    color: #1e293b !important;
                }
                .select2-container--default .select2-selection--single .select2-selection__arrow {
                    height: 42px !important;
                }
                /* Tabs UI */
                .pengoo-tabs { display: flex; gap: 10px; border-bottom: 1px solid #e5e7eb; padding: 0 32px; background: #f8fafc; }
                .pengoo-tab { padding: 16px 20px; font-size: 14px; font-weight: 700; color: #64748b; cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.2s; margin-bottom: -1px; }
                .pengoo-tab:hover { color: #0f172a; }
                .pengoo-tab.active { color: #2e69ff; border-bottom-color: #2e69ff; }
                .pengoo-tab-content { display: none; padding: 32px; }
                .pengoo-tab-content.active { display: block; }
                @media (max-width: 782px) {
                    #wpbody .pengoo-wrap { padding: 15px 10px; }
                    .pengoo-tab-content { padding: 20px; }
                    .pengoo-header { padding: 20px; flex-direction: column; text-align: center; }
                    .pengoo-stats { grid-template-columns: 1fr; }
                    .pengoo-footer { flex-direction: column; gap: 4px; text-align: center; }
                }
            </style>
            
            <script id="pengoo-force-scripts">
                var pengoo_ajax = {
                    ajax_url: "<?php echo esc_js($ajax_url); ?>",
                    nonce: "<?php echo esc_js($nonce); ?>"
                };
                
                jQuery(document).ready(function ($) {
                    // Initialize SelectWoo
                    if ($.fn.selectWoo) {
                        $('.pengoo-select2').selectWoo({
                            width: '100%',
                            templateResult: function (item) {
                                if (!item.id) return item.text;
                                var flag = $(item.element).data('flag') || '';
                                return $('<span>' + flag + ' ' + item.text + '</span>');
                            },
                            templateSelection: function (item) {
                                if (!item.id) return item.text;
                                var flag = $(item.element).data('flag') || '';
                                return $('<span>' + flag + ' ' + item.text + '</span>');
                            }
                        });
                    } else if ($.fn.select2) {
                        $('.pengoo-select2').select2({
                            width: '100%',
                            templateResult: function (item) {
                                if (!item.id) return item.text;
                                var flag = $(item.element).data('flag') || '';
                                return $('<span>' + flag + ' ' + item.text + '</span>');
                            },
                            templateSelection: function (item) {
                                if (!item.id) return item.text;
                                var flag = $(item.element).data('flag') || '';
                                return $('<span>' + flag + ' ' + item.text + '</span>');
                            }
                        });
                    }

                    // Tab Switching Logic
                    $('.pengoo-tab').on('click', function() {
                        $('.pengoo-tab').removeClass('active');
                        $(this).addClass('active');
                        var target = $(this).data('target');
                        $('.pengoo-tab-content').removeClass('active');
                        $('#' + target).addClass('active');
                    });

                    $(document).keydown(function (e) {
                        if (e.altKey && e.shiftKey && e.keyCode === 68) { // D key
                            $('#pengoo-dev-area').fadeToggle();
                        }
                    });

                    $('.pengoo-logo').on('dblclick', function () {
                        $('#pengoo-dev-area').fadeToggle();
                    });

                    $('#pengoo_save_url_btn').on('click', function (e) {
                        e.preventDefault();
                        const btn = $(this);
                        const newUrl = $('#pengoo_app_url_input').val();

                        btn.prop('disabled', true).text('Saving...');

                        $.ajax({
                            url: pengoo_ajax.ajax_url,
                            type: 'POST',
                            data: {
                                action: 'pengoo_save_settings',
                                nonce: pengoo_ajax.nonce,
                                app_url: newUrl
                            },
                            success: function (response) {
                                if (response.success) {
                                    alert('Pengoo App URL updated successfully.');
                                } else {
                                    alert('Error: ' + response.data);
                                }
                            },
                            error: function () {
                                alert('Connection error. Please try again.');
                            },
                            complete: function () {
                                btn.prop('disabled', false).text('Save URL');
                            }
                        });
                    });
                });
            </script>
<?php
        }
    }

    public function register_admin_menu()
    {
        add_submenu_page(
            'woocommerce',
            'Pengoo Settings',
            'Pengoo',
            'manage_woocommerce',
            'pengoo-integration',
            array($this, 'draw_admin_dashboard')
        );
    }

    public function draw_admin_dashboard()
    {
        $is_connected = get_option('pengoo_is_connected', false);
        $site_url = get_site_url();
        $app_base_url = get_option('pengoo_app_url', PENGOO_PLATFORM_URL);
        $connected_at = get_option('pengoo_connected_at', '');
        $logo_url = 'https://rqcragxnihfktgmajfgz.supabase.co/storage/v1/object/public/platform/branding/logo-h2bslhm2uos.png';
        $status_msg = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $wc_countries = function_exists('WC') ? WC()->countries->get_countries() : array();
?>
        <div class="wrap pengoo-wrap">
            <div class="pengoo-card">
                <!-- Header -->
                <div class="pengoo-header">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="Pengoo" class="pengoo-logo">
                    <div class="pengoo-header-text">
                        <h1>Pengoo</h1>
                        <p>WhatsApp Automation for WooCommerce</p>
                    </div>
                </div>

                <!-- Tabs Navigation -->
                <div class="pengoo-tabs">
                    <div class="pengoo-tab active" data-target="tab-dashboard">Dashboard</div>
                    <div class="pengoo-tab" data-target="tab-settings">Settings</div>
                </div>

                <?php if ($status_msg === 'success'): ?>
                    <div class="pengoo-toast pengoo-toast-success">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>
                        Store connected successfully! Your WhatsApp automation is now active.
                    </div>
                <?php elseif ($status_msg === 'disconnected'): ?>
                    <div class="pengoo-toast pengoo-toast-info">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        Store disconnected. You can reconnect anytime.
                    </div>
                <?php endif; ?>

                <!-- TAB: DASHBOARD -->
                <div class="pengoo-tab-content active" id="tab-dashboard">
                    <div class="pengoo-body" style="padding:0;">
                    <?php if ($is_connected): ?>
                        <!-- ═══ CONNECTED STATE ═══ -->
                        <div class="pengoo-status pengoo-status--connected">
                            <div class="pengoo-status-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>
                            </div>
                            <div class="pengoo-status-info">
                                <strong>Connected</strong>
                                <span><?php echo esc_html($site_url); ?></span>
                            </div>
                            <div class="pengoo-status-badge">Active</div>
                        </div>

                        <!-- Stats -->
                        <div class="pengoo-stats">
                            <div class="pengoo-stat">
                                <div class="pengoo-stat-icon">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
                                </div>
                                <div class="pengoo-stat-text">
                                    <span class="pengoo-stat-label">Sync Status</span>
                                    <span class="pengoo-stat-value pengoo-text-success">Active</span>
                                </div>
                            </div>
                            <div class="pengoo-stat">
                                <div class="pengoo-stat-icon">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                                </div>
                                <div class="pengoo-stat-text">
                                    <span class="pengoo-stat-label">WhatsApp</span>
                                    <span class="pengoo-stat-value">Ready</span>
                                </div>
                            </div>
                            <div class="pengoo-stat">
                                <div class="pengoo-stat-icon">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                                </div>
                                <div class="pengoo-stat-text">
                                    <span class="pengoo-stat-label">Webhooks</span>
                                    <span class="pengoo-stat-value pengoo-text-success">Configured</span>
                                </div>
                            </div>
                        </div>

                        <!-- Actions -->
                        <div class="pengoo-actions">
                            <a href="<?php echo esc_url($app_base_url); ?>/dashboard" target="_blank" class="pengoo-btn pengoo-btn-primary">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                                Open Dashboard
                            </a>
                            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST" class="pengoo-disconnect-form">
                                <input type="hidden" name="action" value="pengoo_disconnect">
                                <?php wp_nonce_field('pengoo_disconnect_action', 'pengoo_disconnect_nonce'); ?>
                                <button type="submit" class="pengoo-btn pengoo-btn-ghost pengoo-btn-danger" onclick="return confirm('Are you sure you want to disconnect this store?');">
                                    Disconnect Store
                                </button>
                            </form>
                        </div>

                    <?php else: ?>
                        <!-- ═══ DISCONNECTED STATE ═══ -->
                        <div class="pengoo-status pengoo-status--disconnected">
                            <div class="pengoo-status-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
                            </div>
                            <div class="pengoo-status-info">
                                <strong>Not Connected</strong>
                                <span>Connect your store to start automating WhatsApp messages</span>
                            </div>
                        </div>

                        <!-- Features -->
                        <div class="pengoo-features">
                            <div class="pengoo-feature-item">
                                <div class="pengoo-feature-icon">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
                                </div>
                                <div>
                                    <strong>Order Notifications</strong>
                                    <span>Automatically notify customers on every order status change</span>
                                </div>
                            </div>
                            <div class="pengoo-feature-item">
                                <div class="pengoo-feature-icon">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                                </div>
                                <div>
                                    <strong>Abandoned Cart Recovery</strong>
                                    <span>Recover lost sales with automated WhatsApp reminders</span>
                                </div>
                            </div>
                            <div class="pengoo-feature-item">
                                <div class="pengoo-feature-icon">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                                </div>
                                <div>
                                    <strong>Customer Engagement</strong>
                                    <span>Build smart contact lists and run targeted campaigns</span>
                                </div>
                            </div>
                        </div>

                                             <div class="pengoo-actions">
                            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST">
                                <input type="hidden" name="action" value="pengoo_start_smart_connect">
                                <?php wp_nonce_field('pengoo_start_smart_connect_action', 'pengoo_smart_connect_nonce'); ?>
                                <button type="submit" class="pengoo-btn pengoo-btn-primary pengoo-btn-lg">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                                    Connect Your Store
                                </button>
                            </form>
                            <p class="pengoo-help-text">One-click setup — no API keys required</p>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>

                <!-- TAB: SETTINGS -->
                <div class="pengoo-tab-content" id="tab-settings" style="direction: rtl; text-align: right;">
                    <div class="pengoo-header-text" style="margin-bottom: 24px;">
                        <h2 style="margin:0; font-size:18px; font-weight:800; color:#0f172a;">إعدادات الهاتف (Checkout)</h2>
                        <p style="margin:4px 0 0; color:#64748b; font-size:13px;">تخصيص شكل وخيارات مفتاح الدولة في صفحة الدفع</p>
                    </div>
                    
                    <?php 
                        $enable_phone = get_option('pengoo_enable_phone_field', 0);
                        $default_country = get_option('pengoo_default_country', 'SA');
                        $allowed_countries_raw = get_option('pengoo_allowed_countries', '');
                        $allowed_countries = !empty($allowed_countries_raw) ? array_map('trim', explode(',', $allowed_countries_raw)) : array();
                    ?>
                    <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST" style="max-width: 600px;">
                        <input type="hidden" name="action" value="pengoo_save_phone_settings">
                        <?php wp_nonce_field('pengoo_phone_settings_action', 'pengoo_phone_settings_nonce'); ?>
                        
                        <div style="margin-bottom: 24px;">
                            <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 16px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; transition: all 0.2s;">
                                <input type="checkbox" name="pengoo_enable_phone" value="1" <?php checked($enable_phone, 1); ?> style="width:20px; height:20px; border-radius:6px; border:2px solid #cbd5e1; cursor:pointer;">
                                <div>
                                    <strong style="display:block; font-size:15px; color:#0f172a; margin-bottom:2px;">تفعيل القائمة المنسدلة للدول</strong>
                                    <span style="font-size:13px; color:#64748b;">إظهار أعلام الدول ومفاتيح الاتصال في حقل الجوال الخاص بووكومرس.</span>
                                </div>
                            </label>
                        </div>

                        <div style="margin-bottom: 24px; text-align: right; direction: rtl;">
                            <label style="display:block; font-size:14px; font-weight:700; color:#1e293b; margin-bottom:8px;">الدولة الافتراضية</label>
                            <select name="pengoo_default_country" class="pengoo-select2" style="width:100%;" dir="rtl">
                                <?php foreach ($wc_countries as $code => $name): ?>
                                    <option value="<?php echo esc_attr(strtolower($code)); ?>" data-flag="<?php echo esc_attr($this->get_country_flag($code)); ?>" <?php selected(strtolower($default_country), strtolower($code)); ?>>
                                        <?php echo esc_html($name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p style="font-size:12px; color:#64748b; margin:6px 0 0;">سيتم تحديد هذه الدولة بشكل افتراضي للعملاء.</p>
                        </div>

                        <div style="margin-bottom: 32px; text-align: right; direction: rtl;">
                            <label style="display:block; font-size:14px; font-weight:700; color:#1e293b; margin-bottom:8px;">الدول المسموحة (اختياري)</label>
                            <select name="pengoo_allowed_countries[]" class="pengoo-select2" multiple="multiple" style="width:100%;" dir="rtl" data-placeholder="ابحث عن الدول المسموحة...">
                                <?php foreach ($wc_countries as $code => $name): ?>
                                    <option value="<?php echo esc_attr(strtolower($code)); ?>" data-flag="<?php echo esc_attr($this->get_country_flag($code)); ?>" <?php if(in_array(strtolower($code), $allowed_countries)) echo 'selected="selected"'; ?>>
                                        <?php echo esc_html($name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p style="font-size:12px; color:#64748b; margin:6px 0 0;">اختر الدول المسموح بها. اترك الحقل فارغاً للسماح بجميع دول العالم.</p>
                        </div>
                        
                        <button type="submit" class="pengoo-btn pengoo-btn-primary" style="width:auto; padding:12px 32px;">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                            حفظ الإعدادات
                        </button>
                    </form>
                </div>

                <!-- Footer -->

        </div>
<?php
    }

    public function start_connection_flow()
    {
        if (!isset($_POST['pengoo_smart_connect_nonce']) || !wp_verify_nonce($_POST['pengoo_smart_connect_nonce'], 'pengoo_start_smart_connect_action')) {
            wp_die('Security check failed.');
        }
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Permission denied.');
        }

        $temp_token = wp_generate_password(40, false);
        update_option('pengoo_temp_auth_token', $temp_token);
        update_option('pengoo_temp_auth_time', time());
        $site_url = get_site_url();
        $return_url = admin_url('admin.php?page=pengoo-integration&status=success');
        $locale = get_locale();
        $site_language = substr($locale, 0, 2);

        $redirect_params = array(
            'store_url' => $site_url,
            'temp_token' => $temp_token,
            'return_url' => $return_url,
            'site_language' => $site_language
        );

        $platform_url = get_option('pengoo_app_url', PENGOO_PLATFORM_URL);
        $target_url = add_query_arg($redirect_params, $platform_url . '/woocommerce-auth');

        wp_redirect($target_url);
        exit;
    }

    private function get_store_languages()
    {
        $languages = array();

        if (function_exists('icl_get_languages')) {
            $wpml_langs = icl_get_languages('skip_missing=0');
            if (is_array($wpml_langs)) {
                foreach ($wpml_langs as $lang) {
                    $languages[] = array(
                        'code' => substr($lang['language_code'], 0, 2),
                        'name' => $lang['translated_name'],
                        'native_name' => $lang['native_name'],
                        'is_default' => !empty($lang['active']),
                    );
                }
            }
        } elseif (function_exists('pll_languages_list')) {
            $pll_langs = pll_languages_list(array('fields' => ''));
            if (is_array($pll_langs)) {
                $default_lang = function_exists('pll_default_language') ? pll_default_language() : '';
                foreach ($pll_langs as $lang) {
                    $languages[] = array(
                        'code' => substr($lang->slug, 0, 2),
                        'name' => $lang->name,
                        'native_name' => $lang->name,
                        'is_default' => ($lang->slug === $default_lang),
                    );
                }
            }
        } elseif (class_exists('TRP_Translate_Press')) {
            $trp = TRP_Translate_Press::get_trp_instance();
            $trp_settings = $trp->get_component('settings');
            $settings = $trp_settings->get_settings();
            if (!empty($settings['translation-languages'])) {
                foreach ($settings['translation-languages'] as $lang_code) {
                    $code = substr($lang_code, 0, 2);
                    $languages[] = array(
                        'code' => $code,
                        'name' => $lang_code,
                        'native_name' => $lang_code,
                        'is_default' => ($lang_code === $settings['default-language']),
                    );
                }
            }
        }

        if (empty($languages)) {
            $locale = get_locale();
            $code = substr($locale, 0, 2);
            $languages[] = array(
                'code' => $code,
                'name' => $code === 'ar' ? 'Arabic' : ($code === 'en' ? 'English' : $locale),
                'native_name' => $code === 'ar' ? 'العربية' : ($code === 'en' ? 'English' : $locale),
                'is_default' => true,
            );
        }

        return $languages;
    }

    public function disconnect_store()
    {
        if (!isset($_POST['pengoo_disconnect_nonce']) || !wp_verify_nonce($_POST['pengoo_disconnect_nonce'], 'pengoo_disconnect_action')) {
            wp_die('Security check failed.');
        }
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Permission denied.');
        }

        delete_option('pengoo_is_connected');
        delete_option('pengoo_temp_auth_token');
        delete_option('pengoo_connected_at');

        wp_redirect(admin_url('admin.php?page=pengoo-integration&status=disconnected'));
        exit;
    }

    public function save_developer_settings()
    {
        check_ajax_referer('pengoo_settings_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Unauthorized.');
        }
        if (isset($_POST['app_url'])) {
            $url = esc_url_raw($_POST['app_url']);
            $url = untrailingslashit($url);
            update_option('pengoo_app_url', $url);
            wp_send_json_success('Settings Saved');
        }
        wp_send_json_error('Missing data.');
    }

    public function register_api_endpoints()
    {
        register_rest_route('pengoo/v1', '/exchange-keys', array(
            'methods' => 'POST',
            'callback' => array($this, 'api_handle_key_exchange'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('pengoo/v1', '/store-languages', array(
            'methods' => 'GET',
            'callback' => array($this, 'api_get_store_languages'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('pengoo/v1', '/order-action', array(
            'methods' => 'POST',
            'callback' => array($this, 'api_handle_order_action'),
            'permission_callback' => '__return_true',
        ));
    }

    public function api_get_store_languages()
    {
        return array(
            'success' => true,
            'site_language' => substr(get_locale(), 0, 2),
            'store_languages' => $this->get_store_languages()
        );
    }

    public function api_handle_key_exchange(WP_REST_Request $request)
    {
        $token_received = $request->get_param('temp_token');
        if (empty($token_received))
            return new WP_Error('missing_token', 'temp_token is required', array('status' => 400));

        $stored_token = get_option('pengoo_temp_auth_token');
        $stored_time = get_option('pengoo_temp_auth_time', 0);

        if (empty($stored_token) || $stored_token !== $token_received)
            return new WP_Error('invalid_token', 'Invalid exchange token', array('status' => 401));
        if ((time() - $stored_time) > 900) {
            delete_option('pengoo_temp_auth_token');
            return new WP_Error('expired_token', 'Token expired', array('status' => 401));
        }

        global $wpdb;
        $users = get_users(array('role' => 'administrator', 'number' => 1));
        if (empty($users))
            return new WP_Error('no_admin', 'Admin not found', array('status' => 500));

        $user_id = $users[0]->ID;
        $ck = 'ck_' . wc_rand_hash();
        $cs = 'cs_' . wc_rand_hash();

        $wpdb->insert(
            $wpdb->prefix . 'woocommerce_api_keys',
            array(
                'user_id' => $user_id,
                'description' => 'Pengoo Integration',
                'permissions' => 'read_write',
                'consumer_key' => wc_api_hash($ck),
                'consumer_secret' => $cs,
                'truncated_key' => substr($ck, -7)
            )
        );

        delete_option('pengoo_temp_auth_token');
        update_option('pengoo_is_connected', true);
        update_option('pengoo_connected_at', current_time('mysql'));
        $platform_webhook_secret = sanitize_text_field((string) $request->get_param('webhook_secret'));
        if (!empty($platform_webhook_secret)) {
            update_option('pengoo_webhook_secret', $platform_webhook_secret);
        }

        $locale = get_locale();
        $site_language = substr($locale, 0, 2);

        return array(
            'success' => true,
            'store_url' => get_site_url(),
            'consumer_key' => $ck,
            'consumer_secret' => $cs,
            'webhook_secret' => $this->get_webhook_secret(),
            'site_language' => $site_language,
            'store_languages' => $this->get_store_languages()
        );
    }

    public function api_handle_order_action(WP_REST_Request $request)
    {
        $order_id = absint($request->get_param('order_id'));
        if (!$order_id) {
            $order_id = absint($request->get_param('id'));
        }

        $order = $order_id ? wc_get_order($order_id) : false;
        if (!$order) {
            return new WP_Error('pengoo_order_not_found', 'Order not found.', array('status' => 404));
        }

        $secret = sanitize_text_field((string) $request->get_param('secret'));
        if (empty($secret)) {
            $secret = sanitize_text_field((string) $request->get_header('x-pengoo-secret'));
        }
        $order_key = sanitize_text_field((string) $request->get_param('order_key'));

        $authorization = sanitize_text_field((string) $request->get_header('authorization'));

        if (!$this->is_authorized_order_action($secret, $order_key, $order, $authorization)) {
            return new WP_Error('pengoo_unauthorized', 'Unauthorized order action.', array('status' => 401));
        }

        $raw_action = $request->get_param('action');
        if ($raw_action === null) {
            $raw_action = $request->get_param('status');
        }
        if ($raw_action === null) {
            $raw_action = $request->get_param('response');
        }
        if ($raw_action === null) {
            $raw_action = $request->get_param('button');
        }
        if ($raw_action === null) {
            $meta_data = $request->get_param('meta_data');
            if (is_array($meta_data) && isset($meta_data[0]['value'])) {
                $raw_action = $meta_data[0]['value'];
            }
        }

        $raw_action = sanitize_text_field((string) $raw_action);
        if ($raw_action === '') {
            return new WP_Error('pengoo_missing_action', 'Order action is required.', array('status' => 400));
        }

        $normalized = $this->normalize_order_action($raw_action);
        $label = $this->get_order_action_label($normalized, $raw_action);

        $order->update_meta_data('_pengoo_whatsapp_action', $normalized);
        $order->update_meta_data('_pengoo_whatsapp_action_label', $label);
        $order->update_meta_data('_pengoo_whatsapp_action_raw', $raw_action);
        $order->update_meta_data('_pengoo_whatsapp_action_at', current_time('mysql'));
        $order->update_meta_data('whatsapp_response', $label);
        $order->add_order_note(sprintf('Pengoo WhatsApp response: %s', $label));
        $order->save();

        return array(
            'success' => true,
            'order_id' => $order->get_id(),
            'action' => $normalized,
            'label' => $label
        );
    }

    public function notify_order_change($order_id, $old_status, $new_status, $order)
    {
        if (!get_option('pengoo_is_connected'))
            return;
        
        $app_url = get_option('pengoo_app_url', 'https://pengoo.net');
        $target_url = untrailingslashit($app_url) . '/api/webhooks/woocommerce';

        $locale = get_locale();
        $site_language = substr($locale, 0, 2);
        $wpml_language = get_post_meta($order_id, 'wpml_language', true);
        if (!empty($wpml_language)) {
            $site_language = substr($wpml_language, 0, 2);
        }

        $payload = array(
            'id' => $order_id,
            'status' => $new_status,
            'total' => $order->get_total(),
            'billing' => array(
                'first_name' => $order->get_billing_first_name(),
                'last_name' => $order->get_billing_last_name(),
                'phone' => $order->get_billing_phone(),
                'email' => $order->get_billing_email(),
            ),
            'site_language' => $site_language,
            'store_languages' => $this->get_store_languages()
        );
        wp_remote_post($target_url . '?store_id=' . esc_attr(get_option('pengoo_store_id')) . '&store_url=' . urlencode(get_site_url()), array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-wc-webhook-topic' => 'order.' . $new_status
            ),
            'body' => json_encode($payload),
            'timeout' => 5,
            'blocking' => false
        ));
    }

    private function get_webhook_secret()
    {
        $secret = get_option('pengoo_webhook_secret', '');
        if (empty($secret)) {
            $secret = wp_generate_password(48, false, false);
            update_option('pengoo_webhook_secret', $secret);
        }
        return $secret;
    }

    private function get_country_flag($country_code)
    {
        $country_code = strtoupper(substr((string) $country_code, 0, 2));
        if (strlen($country_code) !== 2 || !ctype_alpha($country_code)) {
            return '';
        }

        $first = 0x1F1E6 + (ord($country_code[0]) - ord('A'));
        $second = 0x1F1E6 + (ord($country_code[1]) - ord('A'));
        return '&#x' . strtoupper(dechex($first)) . ';&#x' . strtoupper(dechex($second)) . ';';
    }

    private function is_authorized_order_action($secret, $order_key, $order, $authorization = '')
    {
        $stored_secret = $this->get_webhook_secret();
        if (!empty($secret) && hash_equals($stored_secret, $secret)) {
            return true;
        }

        if (!empty($order_key) && hash_equals($order->get_order_key(), $order_key)) {
            return true;
        }

        if (!empty($authorization) && stripos($authorization, 'basic ') === 0 && function_exists('wc_api_hash')) {
            $decoded = base64_decode(substr($authorization, 6));
            if ($decoded && strpos($decoded, ':') !== false) {
                list($consumer_key, $consumer_secret) = explode(':', $decoded, 2);
                global $wpdb;
                $stored_secret = $wpdb->get_var($wpdb->prepare(
                    "SELECT consumer_secret FROM {$wpdb->prefix}woocommerce_api_keys WHERE consumer_key = %s LIMIT 1",
                    wc_api_hash($consumer_key)
                ));

                if (!empty($stored_secret) && hash_equals($stored_secret, $consumer_secret)) {
                    return true;
                }
            }
        }

        return false;
    }

    private function normalize_order_action($raw_action)
    {
        $action = strtolower(trim($raw_action));
        $action = str_replace(array('-', '_'), ' ', $action);

        $confirmed = array('1', 'confirm', 'confirmed', 'wc meta confirm', 'wc_meta_confirm', 'approve', 'approved', 'yes', 'y', 'ok', 'accept', 'accepted', 'تم التاكيد', 'تم التأكيد', 'تأكيد', 'تاكيد', 'موافق');
        if (in_array($action, $confirmed, true)) {
            return 'confirmed';
        }

        $cancelled = array('2', 'cancel', 'cancelled', 'canceled', 'wc meta cancel', 'wc_meta_cancel', 'reject', 'rejected', 'no', 'n', 'تم الالغاء', 'تم الإلغاء', 'الغاء', 'إلغاء', 'ملغي');
        if (in_array($action, $cancelled, true)) {
            return 'cancelled';
        }

        return 'custom';
    }

    private function get_order_action_label($normalized, $raw_action = '')
    {
        if ($normalized === 'confirmed') {
            return 'تم التأكيد';
        }

        if ($normalized === 'cancelled') {
            return 'تم الإلغاء';
        }

        if ($raw_action === 'wc_meta_support' || $raw_action === 'support') {
            return 'طلب الدعم';
        }

        return $raw_action !== '' ? $raw_action : 'رد آخر';
    }

    public function add_order_confirmation_meta_box()
    {
        add_meta_box(
            'pengoo_order_confirmation',
            'Pengoo WhatsApp Confirmation',
            array($this, 'render_order_confirmation_meta_box'),
            'shop_order',
            'side',
            'high'
        );

        add_meta_box(
            'pengoo_order_confirmation',
            'Pengoo WhatsApp Confirmation',
            array($this, 'render_order_confirmation_meta_box'),
            'woocommerce_page_wc-orders',
            'side',
            'high'
        );
    }

    public function render_order_confirmation_meta_box($post_or_order)
    {
        $order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order($post_or_order->ID);
        if (!$order) {
            echo '<p>-</p>';
            return;
        }

        wp_nonce_field('pengoo_order_confirmation_action', 'pengoo_order_confirmation_nonce');

        $action = $order->get_meta('_pengoo_whatsapp_action', true);
        $label = $order->get_meta('_pengoo_whatsapp_action_label', true);
        $raw = $order->get_meta('_pengoo_whatsapp_action_raw', true);
        $updated_at = $order->get_meta('_pengoo_whatsapp_action_at', true);

        if (empty($label)) {
            $label = '-';
        }

        echo '<p><strong>Status:</strong> ' . esc_html($label) . '</p>';
        if (!empty($raw) && $raw !== $label) {
            echo '<p><strong>Customer response:</strong> ' . esc_html($raw) . '</p>';
        }
        if (!empty($updated_at)) {
            echo '<p><strong>Updated:</strong> ' . esc_html($updated_at) . '</p>';
        }

        echo '<p><label for="pengoo_whatsapp_action"><strong>Manual status</strong></label></p>';
        echo '<select id="pengoo_whatsapp_action" name="pengoo_whatsapp_action" style="width:100%;">';
        echo '<option value="" ' . selected($action, '', false) . '>-</option>';
        echo '<option value="confirmed" ' . selected($action, 'confirmed', false) . '>تم التأكيد</option>';
        echo '<option value="cancelled" ' . selected($action, 'cancelled', false) . '>تم الإلغاء</option>';
        echo '</select>';
    }

    public function save_order_confirmation_meta_box($order_id)
    {
        if (!isset($_POST['pengoo_order_confirmation_nonce']) || !wp_verify_nonce($_POST['pengoo_order_confirmation_nonce'], 'pengoo_order_confirmation_action')) {
            return;
        }

        if (!current_user_can('edit_shop_order', $order_id)) {
            return;
        }

        if (!isset($_POST['pengoo_whatsapp_action'])) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $action = sanitize_text_field($_POST['pengoo_whatsapp_action']);
        if ($action === '') {
            $order->delete_meta_data('_pengoo_whatsapp_action');
            $order->delete_meta_data('_pengoo_whatsapp_action_label');
            $order->delete_meta_data('_pengoo_whatsapp_action_raw');
            $order->delete_meta_data('_pengoo_whatsapp_action_at');
            $order->delete_meta_data('whatsapp_response');
            $order->save();
            return;
        }

        $label = $this->get_order_action_label($action);
        $order->update_meta_data('_pengoo_whatsapp_action', $action);
        $order->update_meta_data('_pengoo_whatsapp_action_label', $label);
        $order->update_meta_data('_pengoo_whatsapp_action_raw', $label);
        $order->update_meta_data('_pengoo_whatsapp_action_at', current_time('mysql'));
        $order->update_meta_data('whatsapp_response', $label);
        $order->save();
    }

    public function add_plugin_action_links($links)
    {
        $action_link = '<a href="admin.php?page=pengoo-integration" style="font-weight:bold;color:#2e69ff;">Settings</a>';
        array_unshift($links, $action_link);
        return $links;
    }

    public function on_activation()
    {
        set_transient('pengoo_onboarding_jump', true, 60);
        $this->get_webhook_secret();
    }

    public function check_onboarding_redirect()
    {
        if (get_transient('pengoo_onboarding_jump')) {
            delete_transient('pengoo_onboarding_jump');
            if (!isset($_GET['activate-multi'])) {
                wp_safe_redirect(admin_url('admin.php?page=pengoo-integration'));
                exit;
            }
        }
    }

    public function add_whatsapp_action_column($columns)
    {
        $columns['whatsapp_response'] = 'تأكيد واتساب';
        return $columns;
    }

    public function show_whatsapp_action_column_value($column, $post_id)
    {
        if ('whatsapp_response' === $column) {
            $order = wc_get_order($post_id);
            if ($order) {
                $whatsapp_action = $order->get_meta('_pengoo_whatsapp_action_label');
                if (empty($whatsapp_action)) {
                    $whatsapp_action = $order->get_meta('whatsapp_response');
                }
                if (!empty($whatsapp_action)) {
                    echo $this->render_order_action_badge($whatsapp_action);
                } else {
                    echo '-';
                }
            }
        }
    }

    public function show_whatsapp_action_column_value_hpos($column, $order)
    {
        if ('whatsapp_response' === $column) {
            if ($order) {
                $whatsapp_action = $order->get_meta('_pengoo_whatsapp_action_label');
                if (empty($whatsapp_action)) {
                    $whatsapp_action = $order->get_meta('whatsapp_response');
                }
                if (!empty($whatsapp_action)) {
                    echo $this->render_order_action_badge($whatsapp_action);
                } else {
                    echo '-';
                }
            }
        }
    }

    private function render_order_action_badge($label)
    {
        $status_class = 'status-processing';
        if ($label === 'تم التأكيد') {
            $status_class = 'status-completed';
        } elseif ($label === 'تم الإلغاء') {
            $status_class = 'status-cancelled';
        }

        return '<mark class="order-status ' . esc_attr($status_class) . '"><span>' . esc_html($label) . '</span></mark>';
    }
    public function save_phone_settings() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Permission denied.');
        }
        check_admin_referer('pengoo_phone_settings_action', 'pengoo_phone_settings_nonce');

        $enable = isset($_POST['pengoo_enable_phone']) ? 1 : 0;
        $default_country = isset($_POST['pengoo_default_country']) ? strtolower(sanitize_text_field($_POST['pengoo_default_country'])) : 'sa';
        
        $allowed_countries_raw = isset($_POST['pengoo_allowed_countries']) ? $_POST['pengoo_allowed_countries'] : array();
        if (is_array($allowed_countries_raw)) {
            $allowed_countries_arr = array_map('sanitize_text_field', $allowed_countries_raw);
            $allowed_countries_arr = array_map('strtolower', $allowed_countries_arr);
            $allowed_countries_arr = array_values(array_unique(array_filter($allowed_countries_arr)));
            if (!empty($allowed_countries_arr) && !in_array($default_country, $allowed_countries_arr, true)) {
                $allowed_countries_arr[] = $default_country;
            }
            $allowed_countries = implode(',', $allowed_countries_arr);
        } else {
            $allowed_countries = strtolower(sanitize_text_field($allowed_countries_raw));
        }

        update_option('pengoo_enable_phone_field', $enable);
        update_option('pengoo_default_country', $default_country);
        update_option('pengoo_allowed_countries', $allowed_countries);

        wp_redirect(admin_url('admin.php?page=pengoo-integration&status=settings_saved'));
        exit;
    }

    public function enqueue_frontend_assets() {
        if (function_exists('is_checkout') && is_checkout() && get_option('pengoo_enable_phone_field', 0)) {
            // Enqueue intl-tel-input CSS & JS from CDN (v24.8.2 supports search natively)
            wp_enqueue_style('intl-tel-input', 'https://cdn.jsdelivr.net/npm/intl-tel-input@24.8.2/build/css/intlTelInput.css');
            wp_enqueue_script('intl-tel-input', 'https://cdn.jsdelivr.net/npm/intl-tel-input@24.8.2/build/js/intlTelInput.min.js', array(), null, true);

            $default_country = get_option('pengoo_default_country', 'sa');
            $allowed_countries_raw = get_option('pengoo_allowed_countries', '');
            $only_countries = [];
            if (!empty($allowed_countries_raw)) {
                $only_countries = array_map('trim', explode(',', $allowed_countries_raw));
            }

            $script = "
                document.addEventListener('DOMContentLoaded', function() {
                    var input = document.querySelector('#billing_phone');
                    if (input) {
                        var iti = window.intlTelInput(input, {
                            initialCountry: '" . esc_js($default_country) . "',
                            " . (!empty($only_countries) ? "onlyCountries: " . json_encode($only_countries) . "," : "") . "
                            countrySearch: true,
                            fixDropdownWidth: false,
                            separateDialCode: true,
                            nationalMode: false,
                            formatAsYouType: true,
                            utilsScript: 'https://cdn.jsdelivr.net/npm/intl-tel-input@24.8.2/build/js/utils.js',
                        });
                        
                        function pengooFormatPhone() {
                            if (iti.isValidNumber()) {
                                input.value = iti.getNumber();
                            }
                        }
                        
                        input.addEventListener('blur', pengooFormatPhone);
                        input.addEventListener('countrychange', pengooFormatPhone);
                        
                        // Also hook into WooCommerce checkout
                        if (typeof jQuery !== 'undefined') {
                            jQuery('form.checkout').on('checkout_place_order', function() {
                                pengooFormatPhone();
                                return true;
                            });
                        }
                    }
                });
            ";
            wp_add_inline_script('intl-tel-input', $script);
            
            $css = "
                /* Pengoo Phone Field Premium UI */
                .iti { width: 100%; display: block; margin-bottom: 0; }
                .iti__flag-container { direction: ltr; padding: 2px; }
                .iti__selected-country { border-radius: 6px 0 0 6px; background-color: transparent !important; padding: 0 12px !important; }
                .iti--allow-dropdown .iti__flag-container:hover .iti__selected-country { background-color: rgba(0,0,0,0.03) !important; }
                
                /* Input styling overriding WooCommerce defaults */
                .woocommerce form .form-row .input-text.iti__tel-input,
                .iti input[type=tel] { 
                    padding-right: 16px !important; 
                    padding-left: 96px !important; /* Room for flag and dial code */
                    border-radius: 8px !important;
                    border: 1px solid #d1d5db !important;
                    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05) !important;
                    height: 48px !important;
                    font-size: 15px !important;
                    transition: all 0.2s ease !important;
                    background-color: #fff !important;
                    width: 100% !important;
                    margin: 0 !important;
                }
                .woocommerce form .form-row .input-text.iti__tel-input:focus,
                .iti input[type=tel]:focus {
                    border-color: #2e69ff !important;
                    box-shadow: 0 0 0 3px rgba(46, 105, 255, 0.15) !important;
                    outline: none !important;
                }
                
                /* Dropdown list premium styling */
                .iti__dropdown-content {
                    border-radius: 12px !important;
                    border: 1px solid #f3f4f6 !important;
                    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1) !important;
                    margin-top: 8px !important;
                    padding: 8px !important;
                    font-family: inherit !important;
                    z-index: 9999 !important;
                    min-width: 320px !important; /* Ensure it is wide enough */
                    max-width: 400px !important;
                    white-space: nowrap !important;
                }
                /* v24 specific search styling */
                .iti__search-input {
                    padding: 10px 12px !important;
                    border-radius: 6px !important;
                    border: 1px solid #e5e7eb !important;
                    margin-bottom: 8px !important;
                    width: calc(100% - 16px) !important;
                    margin-left: 8px !important;
                    margin-right: 8px !important;
                }
                .iti__country { 
                    padding: 10px 12px !important; 
                    border-radius: 6px !important; 
                    margin-bottom: 2px !important; 
                    transition: background 0.15s !important;
                    display: flex !important;
                    align-items: center !important;
                }
                .iti__country:hover, .iti__country.iti__highlight { 
                    background-color: #f3f4f6 !important; 
                }
                .iti__country-name {
                    font-size: 14px !important;
                    color: #1f2937 !important;
                    font-weight: 500 !important;
                }
                .iti__dial-code {
                    color: #6b7280 !important;
                    font-size: 13px !important;
                    margin-left: auto !important;
                }
                html[dir='rtl'] .iti { direction: ltr !important; }
                html[dir='rtl'] .iti input[type=tel] {
                    direction: ltr !important;
                    text-align: left !important;
                    padding-left: 96px !important;
                    padding-right: 16px !important;
                }
            ";
            wp_add_inline_style('intl-tel-input', $css);
        }
    }
}

new Pengoo_Woo_Connector();
