=== Pengoo WooCommerce Connector ===
Contributors: pengoo
Tags: woocommerce, whatsapp, marketing, automation
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.1.4
WC requires at least: 3.0
WC tested up to: 8.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Connect your WooCommerce store to Pengoo (Pengoo.io) for automated WhatsApp messaging.

== Description ==

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/pengoo-woocommerce-connector` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin.
3. Use the Pengoo Settings page to connect your store.

== Changelog ==

= 1.1.4 =
* Complete Premium UI Redesign aligned with Pengoo.io platform.
* Integrated official Arabic "بينجو" Logo.
* Prioritized "Connect" button at the top of the dashboard.
* Added "Noto Sans Arabic" typography for native RTL support.
* Modernized glassmorphism design with platform-matched colors (#2e69ff).

= 1.1.3 =
* Emergency Fix: Inlined all admin assets to ensure compatibility with restrictive server environments.
* Improved connection button reliability.
* Self-contained dashboard architecture.

= 1.1.2 =
* Unified all PHP logic into the main file.
* Strict WooCommerce dependency checks.
* Integrated official Pengoo logo.
* Added "Connect now" action link in plugin list.
* Improved hook reliability for order processing.
* Security enhancements and class safety checks.

= 1.0.0 =
* Initial release.
